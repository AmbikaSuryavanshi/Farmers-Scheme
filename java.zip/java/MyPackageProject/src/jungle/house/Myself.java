package jungle.house;

import jungle.cave.Tiger;


public class Myself {
public static void main(String[] args) {
	Tiger tiger=new Tiger();
	tiger.roar();
	}
}
