package jungle.cave;

public class Tiger {

	public Tiger() {
		System.out.println("Tiger() ctor....");
	}
	public void roar() {
		System.out.println("Tiger roaring....");
	}

}
