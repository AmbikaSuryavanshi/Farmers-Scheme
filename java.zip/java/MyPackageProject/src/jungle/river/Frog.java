package jungle.river;

public class Frog {

	public Frog() {
		System.out.println("Frog() ctor.....");
	}
	void jump() {
		System.out.println("Frog jumping....");
	}

}
