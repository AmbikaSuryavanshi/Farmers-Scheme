package jungle.tree;

public class Monkey {

	public Monkey() {
	System.out.println("Monkey() ctor.....");
	}
void swinging()
{
	System.out.println("monkey swinging.....");
}
}
