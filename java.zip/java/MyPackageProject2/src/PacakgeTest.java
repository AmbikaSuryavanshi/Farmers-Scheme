import myself.relatives.Uncle;

public class PacakgeTest {

	public static void main(String[] args) {
	
		Uncle uncle = new Uncle();
		
		uncle.probing();
	}

}
