
public class InterfaceTest {

	public static void main(String[] args) {
		reproducing b = new Sparrow();
		//b.eat();
		//b.fear();
		//b.fly();
		//b.layegg();
		//b.walk();
		b.reproduce();
		//b.mimicking();
		System.out.println("------------------------");
		Parrot parrot = new Parrot();
		Sparrow sparrow = new Sparrow();
		Forest forest = new Forest();
		forest.dinig(parrot, sparrow);
		System.out.println("------------------------");
		forest.givingBirth(parrot, sparrow);

	}

}

interface walking {
	void walk();
	
}

interface eating {
	void eat();
}

interface fearing {
	void fear();
}

interface reproducing {
	void reproduce();
}

class Animal implements walking, eating, fearing, reproducing {
	public void walk() {
		System.out.println("animal walking.......");
	}

	public void eat() {
		System.out.println("animal eating......");
	}

	public void fear() {
		System.out.println("animal fearing.....");
	}

	public void reproduce() {
		System.out.println("animal reproducing......");
	}
}

interface layingegg {
	void layegg();
	
}


class Bird extends Animal implements layingegg {

	@Override
	public void walk() {
		System.out.println("bird walking.....");
	}

	@Override
	public void eat() {
		System.out.println("bird eating.....");
	}

	@Override
	public void fear() {
		System.out.println("bird fearing.....");
	}

	@Override
	public void reproduce() {
		System.out.println("bird reproducing.....");
	}

	public void layegg() {
		System.out.println("bird lays egg..........");
	}

	

}

interface mimicking {
	void mimic();
}

class Parrot extends Bird implements mimicking {

	@Override
	public void walk() {
		System.out.println("parrot walking.....");
	}

	@Override
	public void eat() {
		System.out.println("parrot eating.....");
	}

	@Override
	public void fear() {
		System.out.println("parrot fearing.....");
	}

	@Override
	public void reproduce() {
		System.out.println("parrot reproducing.....");
	}

	@Override
	public void layegg() {
		System.out.println("parrot lays egg.....");
	}

	public void mimic() {
		System.out.println("parrot mimics........");
	}

}

interface chirping {
	void chirp();
}

class Sparrow extends Bird implements chirping {

	@Override
	public void walk() {
		System.out.println("sparrow walking.....");
	}

	@Override
	public void eat() {
		System.out.println("sparrow eating.....");
	}

	@Override
	public void fear() {
		System.out.println("sparrow fearing.....");
	}

	@Override
	public void reproduce() {
		System.out.println("sparrow reproducing.....");

	}

	@Override
	public void layegg() {
		System.out.println("sparrow lays egg....");
	}

	public void chirp() {
		System.out.println("sparrow chirping.....");
	}

}

class Forest {
	void dinig(eating x, eating y) {
		x.eat();
		y.eat();
	}
	void givingBirth(layingegg x,layingegg y)
	{
		x.layegg();
		y.layegg();
	}

}

class wings{}
class air{}
class Eyesight{}
class Movement{}

interface Flying
{
	Movement fly(wings x,air y,Eyesight z);
	
}
class FlyingBird extends Bird implements Flying
{

	@Override
	public Movement fly(wings x, air y, Eyesight z) {
		// TODO Auto-generated method stub
		return null;
	}
	
}