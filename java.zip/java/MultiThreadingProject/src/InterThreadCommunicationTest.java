public class InterThreadCommunicationTest {
	public static void main(String[] args) {
		FoodItem food = new FoodItem("Pizza");
		Producer prod = new Producer(food);
		Consumer cons = new Consumer(food);

		prod.start();
		cons.start();

	}
}

class Producer extends Thread {
	FoodItem ref;

	public Producer(FoodItem ref) {
		this.ref = ref;
	}

	void produce() {
		ref.served();
	}

	public void run() {
		produce();
	}
}

class Consumer extends Thread {
	FoodItem ref;

	public Consumer(FoodItem ref) {
		this.ref = ref;
	}

	void consume() {
		ref.eat();
	}

	public void run() {
		consume();
	}
}

class FoodItem {
	String foodItemName;

	boolean isProduced;

	public FoodItem(String foodItemName) {
		this.foodItemName = foodItemName;
	}

	synchronized void eat() {
		if (isProduced == false) {
			System.out.println("Waiting for " + foodItemName + " to be produced....");
			try {
				try {
					Thread.sleep(40);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Consuming...." + foodItemName);
	}

	synchronized void served() {
		if (isProduced == false) {
			System.out.println("Producing..." + foodItemName);
			isProduced = true;

			try {
				Thread.sleep(400);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println("Notifying the waiting thread....");
			notify();
		}
	}
}