
public class ThreadTest {
	public static void main(String[] args) {
		Bike bike=new Bike("Honda");
		bike.ridding();
	    Train train=new Train("\texpress");
	    train.railing();
	    AirPlane airplane=new AirPlane("\t\tBritish Airways");
	    airplane.flying();
	    Boat boat=new Boat("\t\t\tWorld Tour shipping");
	    boat.sailing();
	}

}
class Bike extends Thread
{
	String str;
	Bike(String s)
	{
		str=s;
	}
	void ridding()
	{
		for(int i=0;i<50;i++)
		{
			System.out.println("Bike running.........."+i);
		}
		
	}
	public void run() {
		ridding();
	}
	

}
class Train extends Thread
{
	String str;
	Train(String t)
	{
		str=t;
	}
	void railing()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(str+" Train railing..........");
		}
		
	}
	public void run() { 
		railing();
	}

}
class AirPlane extends Thread
{
	String str;
	AirPlane(String a)
	{
		str=a;
	}
	void flying()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(str+" Airplane flying..........");
		}
		
	}
	public void run() { 
		flying();
	}

}
class Boat extends Thread
{
	String str;
	Boat(String b)
	{
		str=b;
	}
	void sailing()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(str+" Boat sailing..........");
		}
		
	}
	public void run() { 
		sailing();
	}

}