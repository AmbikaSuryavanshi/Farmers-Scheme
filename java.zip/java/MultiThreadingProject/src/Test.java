
public class Test {

	public static void main(String[] args) {
		Pen x=new Pen();
		x.start();
		Chalk c=new Chalk(a);
		c.write();
		
		
	}
	

}

interface Writeable
{
void write();

}


class Pen implements Writeable
{
	
	
	/*Writeable w;
	Pen(Writeable w)
	{
		this.w;
	}
	*/
	void start()
	{
		System.out.println("lets start to write.......");
		System.out.println("take pen.......");
		System.out.println("take paper.........");
		write();
	}
	void start(Chalk a)
	{
		System.out.println("lets start to write.......");
		System.out.println("take chalk.......");
		System.out.println("take blackBoard.........");
		a.write();
	}
	public void write()
	{
		System.out.println("write with pen...............");
	}
}



class FountainPen extends Pen
{
	public void write()
	{
		System.out.println("write with Fountainpen...............");
	}
}



class Stone
{
		
}



class Chalk extends Stone implements Writeable
{
	public void write() { 
		System.out.println("Chalk is writing on the blackboard.....");
	}

		
	
}