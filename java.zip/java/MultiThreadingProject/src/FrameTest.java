import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class FrameTest {

	public static void main(String[] args) {
		Thread t = Thread.currentThread();
		System.out.println("who this t is? " + t.getName());
		System.out.println(" is t alive ? " + t.isAlive());

		MyFrame myframe1 = new MyFrame("counter1", 700, 200, 50, 520, t);
		MyFrame myframe2 = new MyFrame("counter2", 500, 400, 350, 420, t);
		MyFrame myframe3 = new MyFrame("counter3", 800, 300, 750, 120, t);

		Thread t1 = new Thread(myframe1);
		Thread t2 = new Thread(myframe2);
		Thread t3 = new Thread(myframe3);

		System.out.println("priority of t1 : " + t1.getPriority());
		System.out.println("priority of t2 : " + t2.getPriority());
		System.out.println("priority of t3 : " + t3.getPriority());

		System.out.println("t1's name : " + t1.getName());
		System.out.println("t2's name : " + t2.getName());
		System.out.println("t3's name : " + t3.getName());
		t1.setName("counter1");
		t2.setName("counter2");
		t3.setName("counter3");

		System.out.println("t1's new name : " + t1.getName());
		System.out.println("t2's new name : " + t2.getName());
		System.out.println("t3's new name : " + t3.getName());

		System.out.println("before start : is t1 alive ? " + t1.isAlive());
		System.out.println("before start : is t2 alive ? " + t2.isAlive());
		System.out.println("before start : is t3 alive ? " + t3.isAlive());

		t1.start();
		t2.start();
		t3.start();

		try {
			System.out.println("waiting for 10 seconds...");
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("after start : is t1 alive ? " + t1.isAlive());
		System.out.println("after start : is t2 alive ? " + t2.isAlive());
		System.out.println("after start : is t3 alive ? " + t3.isAlive());

		System.out.println("End of main...is it really an end of main??? : " + t.isAlive());
	}
}

class MyFrame extends JFrame implements Runnable {
	JTextField field = new JTextField(50);
	JTextField msg = new JTextField(50);
	Thread t;
	JButton ok = new JButton("OK");

	MyFrame(String title, int w, int h, int x, int y, Thread t) {
		this.t = t;
		setTitle(title);
		setSize(w, h);
		setLocation(x, y);
		setVisible(true);
		add(field);
		setLayout(new FlowLayout());
		add(ok);
		add(msg);
	}

	public void run() {
		for (int i = 0; i < 100000; i++) {
			field.setText("" + i);
			msg.setText("IS MAIN ALIVE? : " + t.isAlive());
			System.out.println("" + i);
		}

	}

}
