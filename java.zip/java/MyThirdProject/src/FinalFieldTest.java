
public class FinalFieldTest {

	public static void main(String[] args) {
		final float PI=3.14f;
		System.out.println("Pi:"+PI);
		
	      float PI1=3.18f;
		System.out.println("Pi1:"+PI1);
	}

}
