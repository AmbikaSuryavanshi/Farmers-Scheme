
public class FinalMethodTest {

	public static void main(String[] args) {
		Human h=new Human();
		h.eat();
		h.walk();
		System.out.println("-------------------");
		System.out.println("final method can't be overridden.....................");
		System.out.println("-------------------");
		Dog d=new Dog();
		d.eat();
		d.walk();
		d.bark();
	
	}

}

final class Human
{
	final void walk()
	{
		System.out.println("Human walking....");
	}
	void eat()
	{
		System.out.println("Human eating.....");
	}
}

class Dog extends Human
{
	void walk()
	{
		System.out.println("Dog walking....");
	}
	void eat()
	{
		System.out.println("Dog eating.....");
	}
	void bark()
	{
		System.out.println("Dog Barking.....");
	}
}