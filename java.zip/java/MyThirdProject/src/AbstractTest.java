
public class AbstractTest {

	public static void main(String[] args) {
	   Cutter c=new Cutter();
		c.use();
		c.operating();
		c.sterile();
		c.cut();

	}

}

abstract class Instrument
{
	abstract void use();
}



abstract class MedicalInstrument extends Instrument
{
	abstract void operating();
}

abstract class SurgicalInstrument extends MedicalInstrument
{
	abstract void sterile();
}


/*class SurgicalInstrument extends MedicalInstrument
{

	@Override
	void operating() {
		System.out.println("SurgicalInstrument operated....");
		
	}

	@Override
	void use() {
		System.out.println("SurgicalInstrument used.........");
	}
	
	void sterile()
	{
		System.out.println("SurgicalInstrument sterilised.........");
	}
}*/
 
 
 
 
class Cutter extends SurgicalInstrument
{

	@Override
	void sterile() {
		System.out.println("Cutter sterilised....");
		
	}

	@Override
	void operating() {
		System.out.println("cutter operated....");
		
	}

	@Override
	void use() {
	System.out.println("cutter used.........");
		
	}
	
	void cut()
	{
		System.out.println("cutter used to cut.......");
	}
	
}