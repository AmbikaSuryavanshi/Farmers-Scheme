
public class AnimalTest {

	public static void main(String[] args) {
		Animal animal=new Animal();
		animal.walk();
		animal.eat();
		animal.fear();
		animal.reproduction();
		System.out.println("------------------");
		Bird ref1 =new Parrot();
		ref1.eat();
		ref1.fly();
		Parrot x=new Parrot();
		System.out.println("------------------");
		x.eat();
		x.mimic();
		Sparrow y=new Sparrow();
		System.out.println("------------------");
		y.chirp();
		Animal ref2 = new Bird();
		System.out.println("----------------");
		ref2.eat();
		ref2.fear();
		ref2.reproduction();
	}
}

class AnotherBird
{
	void anotherBird(Parrot x, Sparrow y)
	{
		x.eat();
		y.chirp();
	}
	
}

class Animal
{
	void walk()
	{
		System.out.println("animal walking.......");
	}
	void eat()
	{
		System.out.println("animal eating......");
	}
	void fear()
	{
		System.out.println("animal fearing.....");
	}
	void reproduction()
	{
		System.out.println("animal reproducing......");
	}
}

class Bird extends Animal
{

	@Override
	void walk() {
		System.out.println("bird walking.....");
	}

	@Override
	void eat() {
		System.out.println("bird eating.....");
	}

	@Override
	void fear() {
		System.out.println("birdfearing.....");
	}

	@Override
	void reproduction() {
		System.out.println("bird reproducing.....");
	}
	
	void layegg()
	{
		System.out.println("bird lays egg..........");
	}
	void fly()
	{
		System.out.println("bird flying.........");
	}
	
}

class Parrot extends Bird
{

	@Override
	void walk() {
		System.out.println("parrot walking.....");
	}

	public void chirp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void eat() {
		System.out.println("parrot eating.....");
	}

	@Override
	void fear() {
		System.out.println("parrot fearing.....");
	}

	@Override
	void reproduction() {
		System.out.println("parrot reproducing.....");
	}

	@Override
	void layegg() {
		System.out.println("parrot lays egg.....");
	}

	@Override
	void fly() {
		System.out.println("parrot flying.....");
	}
	
	void mimic()
	{
		System.out.println("parrot mimics........");
	}
	
}

class Sparrow extends Bird
{

	@Override
	void walk() {
		System.out.println("sparrow walking.....");
	}

	@Override
	void eat() {
		System.out.println("sparrow eating.....");
	}

	@Override
	void fear() {
		System.out.println("sparrow fearing.....");
	}

	@Override
	void reproduction() {
		System.out.println("sparrow reproducing.....");
				
	}

	@Override
	void layegg() {
		System.out.println("sparrow lays egg....");
	}

	@Override
	void fly() {
		System.out.println("sparrow flying.....");
	}
	
	void chirp()
	{
		System.out.println("sparrow chirping.....");
	}
	
}