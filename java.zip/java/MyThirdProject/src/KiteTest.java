

public class KiteTest {

	public static void main(String[] args) {
		Kite.printKiteCount();

		Kite k1 = new Kite("Cyan", "Subramanya", 30, true);
		Kite k2 = new Kite("Red", "Sidhharth", 50, true);
		Kite k3 = new Kite("Green", "Shriharsha", 40, true);
		
		System.out.println("k1 : "+k1);
		System.out.println("k2 : "+k2);
		System.out.println("k3 : "+k3);

		Kite.printKiteCount();

		Kite k4 = new Kite("Blue", "Ambika", 40, true);
		Kite k5 = new Kite("Magenta", "Garima", 50, true);
		
		System.out.println("k4 : "+k4);
		System.out.println("k5 : "+k5);

		Kite.printKiteCount();
		
		k2.kiteFight(k3);
		
		Kite.printKiteCount();
	}

}

class Kite {
	private String kiteColor;
	private String kiteOwner;
	private int kiteLength;
	private boolean flying;
	

	private static int kiteCount;
	public static void printKiteCount() {
		System.out.println("Total kites : " + kiteCount);
	}


	public void kiteFight(Kite refToKite) {
		System.out.println(kiteOwner+" initiated kite Fight with " +refToKite.kiteOwner);
		for(int i = 0;i<10;i++)
		{
			double d=Math.random()%100;
			if(d<0.5)
			{
				kiteCount--;
				flying=false;
				System.out.println("Mine: Ohh kite of "+kiteOwner+" is down");
				break;
			}
			else if(d>0.75)
			{
				kiteCount--;
				flying=false;
				System.out.println("Your: Wow kite of "+refToKite.kiteOwner+" is down");
				break;
			}
			else if(d>0.5 && d< 0.75)
			{
		
				flying=false;
				refToKite.flying=false;
				System.out.println("Both: Ohh kite of "+kiteOwner+" is down");
				System.out.println("Both: Wow kite of "+refToKite.kiteOwner+" is down");
				kiteCount--;
				kiteCount--;
				break;
			}
		}
		
	}

	public Kite(String kiteColor, String kiteOwner, int kiteLength, boolean flying) {
		super();
		this.kiteColor = kiteColor;
		this.kiteOwner = kiteOwner;
		this.kiteLength = kiteLength;
		this.flying = flying;
		kiteCount++;
	}

	@Override
	public String toString() {
		return "Kite [kiteColor=" + kiteColor + ", kiteOwner=" + kiteOwner + ", kiteLength=" + kiteLength + ", flying="
				+ flying + "]";
	}

	public String getKiteColor() {
		return kiteColor;
	}

	public void setKiteColor(String kiteColor) {
		this.kiteColor = kiteColor;
	}

	public String getKiteOwner() {
		return kiteOwner;
	}

	public void setKiteOwner(String kiteOwner) {
		this.kiteOwner = kiteOwner;
	}

	public int getKiteLength() {
		return kiteLength;
	}

	public void setKiteLength(int kiteLength) {
		this.kiteLength = kiteLength;
	}

	public boolean isFlying() {
		return flying;
	}

	public void setFlying(boolean flying) {
		this.flying = flying;
	}

}
	
	
	
	
	
	


	
	
