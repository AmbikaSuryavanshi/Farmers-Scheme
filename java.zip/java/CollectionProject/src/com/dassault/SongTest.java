package com.dassault;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class SongTest {

	public static void main(String[] args) {
		Song song1=new Song("Jhoome Jo Pathhan","Arijit Singh","Pathan",2022);
		Song song2=new Song("Zhingat","Ajay Atul","Sairat",2025);
		Song song3=new Song("Aaj Ki party","Mika Singh","Bajrangi Bhai Jan",2026);
		
		ArrayList<Song> myplaylist=new ArrayList<Song>();
		//TreeSet<Song> myplaylist=new TreeSet<Song>();
		
		
		System.out.println("1st song added......");
		myplaylist.add(song1);
		System.out.println("-----------------------------------------------");
		System.out.println("2nd song added......");
		myplaylist.add(song2);
		System.out.println("-----------------------------------------------");
		System.out.println("3rd song added......");
		myplaylist.add(song3);
		System.out.println("-----------------------------------------------");
		
		System.out.println("Sorting.....");
		Collections.sort(myplaylist);
		System.out.println("Sorted......");
		System.out.println("-----------------------------------------------");
		
		 Iterator<Song> songIterator = myplaylist.iterator();
	        while(songIterator.hasNext()) {
	        	Song x = songIterator.next();
	        	
	        	System.out.println("x "+x);
	        }
	}

}
class Song implements Comparable<Song>
{
	String title;
	String artist;
	String album;
	int year;
	
	public int compareTo(Song x) { 
		  System.out.println("comparing "+album+ " with "+x.album);
		  return album.compareTo(x.album);
	  }
	 

	public int compareTo1(Song x) {
   		System.out.println("comparing "+year+ " with "+x.year);
   		return Integer.compare(year, x.year);
   	}
	
	
	public Song(String title, String artist, String album, int year) {
		super();
		this.title = title;
		this.artist = artist;
		this.album = album;
		this.year = year;
	}
	@Override
	public String toString() {
		return "Song [title=" + title + ", artist=" + artist + ", album=" + album + ", year=" + year + ", toString()="
				+ super.toString() + "]";
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
}