package com.dassault;

public class CricketePlayer extends Player
{
	int rank;
	String name;
	String country;
	int totalruns;
	int totalSixersHit;
	int totalFourHits;
	int currentrun;
	int age;
	float strikerate;
	public CricketePlayer(int rank,String name, String country, int totalruns, int totalSixersHit, int totalFourHits,
			int currentrun, int age, float strikerate) {
		super();
		this.rank = rank;
		this.name = name;
		this.country = country;
		this.totalruns = totalruns;
		this.totalSixersHit = totalSixersHit;
		this.totalFourHits = totalFourHits;
		this.currentrun = currentrun;
		this.age = age;
		this.strikerate = strikerate;
	}
	@Override
	public String toString() {
		return "CricketPlayer [rank=" + rank + ", name=" + name + ", country=" + country + ", totalruns=" + totalruns
				+ ", totalSixersHit=" + totalSixersHit + ", totalFourHits=" + totalFourHits + ", currentrun="
				+ currentrun + ", age=" + age + ", strikerate=" + strikerate + ", toString()=" + super.toString() + "]";
	}
	
	public void printCricketplayer()
	{
		System.out.println("Rank:"+rank);
		System.out.println("name:"+name);
		System.out.println("country:"+country);
		System.out.println("totalruns:"+totalruns);
		System.out.println("totalSixersHit:"+totalSixersHit);
		System.out.println("totalFourHits:"+totalFourHits);
		System.out.println("currentrun:"+currentrun);
		System.out.println("age:"+age);
		System.out.println("strikerate:"+strikerate);
	}
}