package com.dassault;
import java.util.ArrayList;
import java.util.Scanner;

public class DynamicTest {

	public static void main(String[] args) {
		
		ArrayList playerList = new ArrayList();
		
		int choice=0;
		int rank=0;

		do
		{
			Scanner Scan1 = new Scanner(System.in);
			System.out.println("Enter player name : ");
			String playerName = Scan1.nextLine();
			
			Scanner Scan2 = new Scanner(System.in);
			System.out.println("Enter total score till now : ");
			int totalScore = Scan2.nextInt();
			
			Scanner Scan3 = new Scanner(System.in);
			System.out.println("Enter current run : ");
			int currentRun = Scan3.nextInt();
			
			Scanner Scan4 = new Scanner(System.in);
			System.out.println("Enter total sixers : ");
			int totSix = Scan4.nextInt();
			
			Scanner Scan5 = new Scanner(System.in);
			System.out.println("Enter total fours : ");
			int totFor = Scan5.nextInt();
			
			Scanner Scan6 = new Scanner(System.in);
			System.out.println("Enter age  : ");
			int age = Scan6.nextInt();
			
			
			Scanner Scan7 = new Scanner(System.in);
			System.out.println("Enter strike rate : ");
			float  strikeRt = Scan5.nextFloat();
			
			CricketePlayer cricketer = new CricketePlayer(++rank, playerName, "India", totalScore, currentRun, totSix, totFor,age,strikeRt);
			
			playerList.add(cricketer);
			
			Scanner Scan8 = new Scanner(System.in);
			System.out.println("press 0 to continue and press 1 to quit : ");
			choice  = Scan8.nextInt();
		
			
		} while(choice!=1);
		
		for (int i = 0; i < playerList.size(); i++) {
			CricketePlayer x = (CricketePlayer) playerList.get(i);
			x.printCricketplayer();	
		}
	}

}