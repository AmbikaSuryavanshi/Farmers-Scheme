package com.dassault;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
	TreeSet<Integer> num=new TreeSet<Integer>();
	num.add(50);
	num.add(60);
	num.add(55);
	num.add(40);
	num.add(35);
	num.add(70);
	num.add(45);
	
Iterator<Integer> numIter=num.iterator();
 while(numIter.hasNext())
 {
	int x =(Integer)numIter.next();
	System.out.println("num:"+x);
	}
 System.out.println("--------------------------------------");

	TreeSet<String> str=new TreeSet<String>();
	str.add("Oxygen");
	str.add("Helium");
	str.add("Lithium");
	str.add("Silver");
	str.add("Gold");
	str.add("Aluminium");
	str.add("Arsenic");
	
Iterator<String> strIter=str.iterator();
 while(strIter.hasNext())
 {
	String y =(String)strIter.next();
	System.out.println("str:"+y);
	}
	}
}

