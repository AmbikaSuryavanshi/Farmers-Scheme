
public class ArraysOfObject {

	public static void main(String[] args) {
		
	
		CricketPlayer player1 = new CricketPlayer(3, "Sachin", "india", 200, 300, 90, 80, 70, 78.5f);
		CricketPlayer player2 = new CricketPlayer(2, "kohli", "india", 300, 300, 90, 80, 60, 68.5f);
		CricketPlayer player3 = new CricketPlayer(1, "Sehvag", "india", 400, 300, 90, 80, 50, 85.5f);
		CricketPlayer player4 = new CricketPlayer(3, "Dhoni", "india", 600, 300, 90, 80, 90, 76.5f);

		CricketPlayer teamIndia[] = new CricketPlayer[11];
		teamIndia[0] = player1;
		teamIndia[1] = player2;
		teamIndia[2] = player3;
		teamIndia[3] = player4;

		try {
			for (int j = 0; j < teamIndia.length; j++) {

				System.out.println("team India       :" + teamIndia[j]);
				teamIndia[j].printCricketplayer();
				System.out.println("-----------------------------------");
			}

		} catch (NullPointerException e) {
			System.out.println(e.getMessage());
		}
	}
}

	class Player {

	}

class CricketPlayer extends Player
{
	int rank;
	String name;
	String country;
	int totalruns;
	int totalSixersHit;
	int totalFourHits;
	int currentrun;
	int age;
	float strikerate;
	public CricketPlayer(int rank,String name, String country, int totalruns, int totalSixersHit, int totalFourHits,
			int currentrun, int age, float strikerate) {
		super();
		this.rank = rank;
		this.name = name;
		this.country = country;
		this.totalruns = totalruns;
		this.totalSixersHit = totalSixersHit;
		this.totalFourHits = totalFourHits;
		this.currentrun = currentrun;
		this.age = age;
		this.strikerate = strikerate;
	}
	@Override
	public String toString() {
		return "CricketPlayer [rank=" + rank + ", name=" + name + ", country=" + country + ", totalruns=" + totalruns
				+ ", totalSixersHit=" + totalSixersHit + ", totalFourHits=" + totalFourHits + ", currentrun="
				+ currentrun + ", age=" + age + ", strikerate=" + strikerate + ", toString()=" + super.toString() + "]";
	}
	
	void printCricketplayer()
	{
		System.out.println("Rank:"+rank);
		System.out.println("name:"+name);
		System.out.println("country:"+country);
		System.out.println("totalruns:"+totalruns);
		System.out.println("totalSixersHit:"+totalSixersHit);
		System.out.println("totalFourHits:"+totalFourHits);
		System.out.println("currentrun:"+currentrun);
		System.out.println("age:"+age);
		System.out.println("strikerate:"+strikerate);
	}
}