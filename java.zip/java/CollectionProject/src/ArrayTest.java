
public class ArrayTest {

	public static void main(String[] args) {
		int teamIndia[]=new int[5];
		teamIndia[0]=5;
		teamIndia[1]=10;
		teamIndia[2]=15;
		teamIndia[3]=20;
		teamIndia[4]=25;
		//teamIndia[5]=25;
		
		int totalscore=0;
		for(int i=0;i<teamIndia.length;i++)
		{
			System.out.println("batsman       :" +teamIndia[i]);
			totalscore=totalscore+teamIndia[i];
		}
		System.out.println("-----------------------------------");
		System.out.println("totalScore    :"+totalscore);
		
		/*int batsman1=5;
		int batsman2=10;
		int batsman3=15;
		int batsman4=20;
		int batsman5=25;
		
		System.out.println("batsman1:"+batsman1);
		System.out.println("batsman1:"+batsman2);
		System.out.println("batsman1:"+batsman3);
		System.out.println("batsman1:"+batsman4);
		System.out.println("batsman1:"+batsman5);
		
		int totalscore = batsman1+batsman2+batsman3+batsman4+batsman5;
		System.out.println("totalscore:"+totalscore);
		
*/
	}

}
