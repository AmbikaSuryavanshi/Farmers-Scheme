import java.util.Iterator;
import java.util.LinkedList;

public class ArraysListOfObjectsTest {

	public static void main(String[] args) {
		
		
		CricketPlayer player1 = new CricketPlayer(3, "Sachin", "India", 12000, 300, 200, 89, 25, 78.3f);
		CricketPlayer player2 = new CricketPlayer(5, "Kohli", "India",11000, 200, 100, 59, 23, 79.2f);
		CricketPlayer player3 = new CricketPlayer(1, "Sehvag", "India",9000, 100, 140, 79, 22, 56.4f);
		CricketPlayer player4 = new CricketPlayer(8, "Dhoni", "India",12000, 750, 140, 84, 29, 89.3f);
		CricketPlayer player5 = new CricketPlayer(4, "Yuvraj", "India",7000, 130, 200, 34, 27, 38.7f);
		
		//ArrayList       teamIndiaList = new ArrayList(); 
		LinkedList       teamIndiaList = new LinkedList(); 
		
		teamIndiaList.add(player1);
		teamIndiaList.add(player2);
		teamIndiaList.add(player3);
		teamIndiaList.add(player4);
		teamIndiaList.add(player5);
		
		
		Iterator teamIterator=teamIndiaList.iterator();
		
		while(teamIterator.hasNext()) {
			CricketPlayer x = (CricketPlayer) teamIterator.next();
			x.printCricketplayer();	
			System.out.println("---------------------------------------");
		}
		
		
	/*for (int i = 0; i < teamIndiaList.size(); i++) { 
			CricketPlayer x = (CricketPlayer) teamIndiaList.get(i);
			x.printCricketplayer();	
			System.out.println("---------------------------------------");
		}*/
	System.out.println("for each array list");
	System.out.println("---------------------------------------");
		for (Object object : teamIndiaList) {
			CricketPlayer x = (CricketPlayer) object;
			x.printCricketplayer();	
			System.out.println("---------------------------------------");
		}
	}
	}

