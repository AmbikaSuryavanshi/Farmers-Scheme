
public class calculationTest {

	public static void main(String[] args) {
		calculator c=new calculator();
		c.calculation1();
		System.out.println("------------------------");
		c.calculation2(10, 4);
		System.out.println("------------------------");
		int sum = c.calculation3(16, 11);
		System.out.println("sum:"+sum);
		System.out.println("------------------------");
		int sum1 = c.calculation4();
		System.out.println("sum1:"+sum1);
	}

}

class calculator
{
	void calculation1()
	{
		System.out.println("No Return No Argument");
	}
	
	
	void calculation2(int x,int y)
	{
	System.out.println("No Return but calculation2(int c,int y)");
	int sum = x+y;
	System.out.println("addition is:"+sum);
	}
	
	int  calculation3(int x,int y)
	{
		return x + y;
		
	}
	
	int calculation4()
	{
		System.out.println(" int calculation");
		return 12+10;
	}

}