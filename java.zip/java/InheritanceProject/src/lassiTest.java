
public class lassiTest {


	public static void main(String[] args)
	{
		
		curd c1 =  new curd("Cow","Thick","offwhite","Sour",100);			
		System.out.println("The Curd : "+c1);
		
		sugar Sugar = new sugar("White", "Crystal", 50, "WhiteSilver", "Very Sweet", false);
		
		

		kitchen myKitchen = new kitchen();
		
		lassi myLassi= myKitchen.makeLassi(c1, Sugar);
		
		System.out.println("Lassi is ready  : "+myLassi);
	}


	}


class lassi
{
	int quantity;
	String flavour;
	String density;
	public lassi(int quantity, String flavour, String density) {
		super();
		this.quantity = quantity;
		this.flavour = flavour;
		this.density = density;
	}
	@Override
	public String toString() {
		return "lassi [quantity=" + quantity + ", flavour=" + flavour + ", density=" + density + "]";
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getFlavour() {
		return flavour;
	}
	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}
	public String getDensity() {
		return density;
	}
	public void setDensity(String density) {
		this.density = density;
	}
	public lassi() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
class kitchen
{
	lassi makeLassi(curd x, sugar y)
	{
		System.out.println("quantity of curd:"  +x.getQuantity());
		System.out.println("quantity of sugar:" +y.getQuantity());
		System.out.println("blend this " +x.getDensity()+ " curd with "+y.getTaste()+" sugar to make lassi ");
		
		lassi Lassi=new lassi();
		Lassi.setDensity(x.getDensity());
		Lassi.setFlavour(y.getTaste());
		Lassi.setQuantity(x.getQuantity());
		return Lassi;
	}
	
}





class curd
{
	String curdType;
	String density;
	String color;
	String taste;
	int quantity;
	public curd(String curdType, String density, String color, String taste, int quantity) {
		super();
		this.curdType = curdType;
		this.density = density;
		this.color = color;
		this.taste = taste;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "curd [curdType=" + curdType + ", density=" + density + ", color=" + color + ", taste=" + taste
				+ ", quantity=" + quantity + ", toString()=" + super.toString() + "]";
	}
	public String getCurdType() {
		return curdType;
	}
	public void setCurdType(String curdType) {
		this.curdType = curdType;
	}
	public String getDensity() {
		return density;
	}
	public void setDensity(String density) {
		this.density = density;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
}




class sugar
{
	String type;
	String color;
	int quantity;
	String form;
	String taste;
	boolean organic;
	public sugar(String type, String color, int quantity, String form, String taste, boolean organic) {
		super();
		this.type = type;
		this.color = color;
		this.quantity = quantity;
		this.form = form;
		this.taste = taste;
		this.organic = organic;
	}
	@Override
	public String toString() {
		return "sugar [type=" + type + ", color=" + color + ", quantity=" + quantity + ", form=" + form + ", taste="
				+ taste + ", organic=" + organic + "]";
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getForm() {
		return form;
	}
	public void setForm(String form) {
		this.form = form;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public boolean isOrganic() {
		return organic;
	}
	public void setOrganic(boolean organic) {
		this.organic = organic;
	}


	
}
