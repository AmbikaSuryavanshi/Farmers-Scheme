
public class MultiLevelInheritanceTest {

	public static void main(String[] args) {
		Person person=new Person("ambika",'F',21);
		System.out.println("p:"+person);
		System.out.println("------------------------------------");
		Student student=new Student("Dhondiba",'M',49,101,98.5f,32.9f,"NIE");
		System.out.println("s:"+student);
		System.out.println("------------------------------------");
		Employee employee=new Employee("Laxmi",'F',47,234,86.5f,97.5f,"NIEMT",132,"Developer","DassaultSystemes");
		System.out.println("e:"+employee);
		
	}
	}

class Person
{
	String Name;
	char gender;
	int age;
	Person()
	{
		System.out.println("person() constructor");
	}
	public Person(String name, char gender, int age) {
		super();
		Name = name;
		this.gender = gender;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [Name=" + Name + ", gender=" + gender + ", age=" + age + "]";
	}
	
	
}

class Student extends Person
{
	int rollNumber;
	float totalMarks;
	float averageMarks;
	String collegeName; 
	Student()
	{
		System.out.println("student() constructor");
	}
	public Student(String name, char gender, int age, int rollNumber, float totalMarks, float averageMarks,
			String collegeName) {
		super(name, gender, age);
		this.rollNumber = rollNumber;
		this.totalMarks = totalMarks;
		this.averageMarks = averageMarks;
		this.collegeName = collegeName;
	}
	@Override
	public String toString() {
		return "Student [toString()=" + super.toString() + ", rollNumber=" + rollNumber + ", totalMarks=" + totalMarks
				+ ", averageMarks=" + averageMarks + ", collegeName=" + collegeName + "]";
	}
	
	
	
}

class Employee extends Student
{
	int employeeID;
	String designation;
	String companyName;
    Employee()
    {
    	System.out.println("employee() constructor");
    }
	public Employee(String name, char gender, int age, int rollNumber, float totalMarks, float averageMarks,
			String collegeName, int employeeID, String designation, String companyName) {
		super(name, gender, age, rollNumber, totalMarks, averageMarks, collegeName);
		this.employeeID = employeeID;
		this.designation = designation;
		this.companyName = companyName;
	}
	@Override
	public String toString() {
		return "Employee [toString()=" + super.toString() + ", employeeID=" + employeeID + ", designation="
				+ designation + ", companyName=" + companyName + "]";
	}
	

	
    
}