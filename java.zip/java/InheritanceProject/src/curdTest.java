
public class curdTest {

	public static void main(String[] args) {
		curd c1=new curd("cow", "thick", "offwhite", "sour", 5);
		System.out.println("The curd:"+c1);
		System.out.println("-------------------------");
		
		System.out.println("The curd adress           :"+c1.hashCode());
		System.out.println("-------------------------");
		
		System.out.println("quantity   :"+c1.getQuantity());
		System.out.println("density    :"+c1.getDensity());
		System.out.println("-------------------------");
		
		curd c2=c1;
		System.out.println("anothercurd               :"+c2.hashCode());
		System.out.println("-------------------------");
		
		curd c3=c1;
		System.out.println("one more curd             :"+c3.hashCode());
		

	}

}
class curd
{
	String curdType;
	String density;
	String color;
	String taste;
	int quantity;
	public curd(String curdType, String density, String color, String taste, int quantity) {
		super();
		this.curdType = curdType;
		this.density = density;
		this.color = color;
		this.taste = taste;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "curd [curdType=" + curdType + ", density=" + density + ", color=" + color + ", taste=" + taste
				+ ", quantity=" + quantity + ", toString()=" + super.toString() + "]";
	}
	public String getCurdType() {
		return curdType;
	}
	public void setCurdType(String curdType) {
		this.curdType = curdType;
	}
	public String getDensity() {
		return density;
	}
	public void setDensity(String density) {
		this.density = density;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
}
