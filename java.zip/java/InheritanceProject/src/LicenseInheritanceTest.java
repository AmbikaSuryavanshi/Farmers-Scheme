

public class LicenseInheritanceTest {


	public static void main(String[] args) {
	            
		

	}

}
class student
{
	String name;
	int rollNumber;
	char gender;
	int age;
	
	student()
	{
		System.out.println("student() constructor");
	}

	public student(String name, int rollNumber, char gender, int age) {
		super();
		this.name = name;
		this.rollNumber = rollNumber;
		this.gender = gender;
		this.age = age;
	}

	@Override
	public String toString() {
		return "student [toString()=" + super.toString() + ", name=" + name + ", rollNumber=" + rollNumber + ", gender="
				+ gender + ", age=" + age + "]";
	}

	


}
class library extends student
{
   String department;
   String libraryName;
   String typeOfLibrary;
   library()
   {
	   System.out.println("library() constructor");  
   }
public library(String name, int rollNumber, char gender, int age, String department, String libraryName,
		String typeOfLibrary) {
	super(name, rollNumber, gender, age);
	this.department = department;
	this.libraryName = libraryName;
	this.typeOfLibrary = typeOfLibrary;
}
@Override
public String toString() {
	return "library [toString()=" + super.toString() + ", department=" + department + ", libraryName=" + libraryName
			+ ", typeOfLibrary=" + typeOfLibrary + "]";
}
   

   
}



class Book extends library
{
	String bookName;
	int bookNumber;
	String bookAuthor;
	Book()
	{
		System.out.println("Book() constructor");
	}
	public Book(String name, int rollNumber, char gender, int age, String department, String libraryName,
			String typeOfLibrary, String bookName, int bookNumber, String bookAuthor) {
		super(name, rollNumber, gender, age, department, libraryName, typeOfLibrary);
		this.bookName = bookName;
		this.bookNumber = bookNumber;
		this.bookAuthor = bookAuthor;
	}
	@Override
	public String toString() {
		return "Book [toString()=" + super.toString() + ", bookName=" + bookName + ", bookNumber=" + bookNumber
				+ ", bookAuthor=" + bookAuthor + "]";
	}
	


}





class page extends Book
{
	int numberOfPages;
	int lenght;
	int width;
	page()
	{
		System.out.println("page() constructor");
	}
	public page(String name, int rollNumber, char gender, int age, String department, String libraryName,
			String typeOfLibrary, String bookName, int bookNumber, String bookAuthor, int numberOfPages, int lenght,
			int width) {
		super(name, rollNumber, gender, age, department, libraryName, typeOfLibrary, bookName, bookNumber, bookAuthor);
		this.numberOfPages = numberOfPages;
		this.lenght = lenght;
		this.width = width;
	}
	@Override
	public String toString() {
		return "page [toString()=" + super.toString() + ", numberOfPages=" + numberOfPages + ", lenght=" + lenght
				+ ", width=" + width + "]";
	}
	
	
	
}