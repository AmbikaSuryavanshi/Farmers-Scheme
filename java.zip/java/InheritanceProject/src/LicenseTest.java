
public class LicenseTest {
	
	public static void main(String[] args) {
		
		License l=new License(12,"ambika",'F');
		System.out.println("l:"+l);
		System.out.println("----------------------------------");
		DrivingLicense d =new DrivingLicense(12,"ambika",'F',"Car", 2);
		System.out.println("d:"+d);
		//DigitalDrivingLicense d2=new DigitalDrivingLicense();
		

	}

}
class License
{
	int licenseId;
	String Name;
	char gender;
	License()
	{
		System.out.println("l() constructor");
	}
	public License(int licenseId, String name, char gender) {
		super();
		this.licenseId = licenseId;
		Name = name;
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "License [licenseId=" + licenseId + ", Name=" + Name + ", gender=" + gender + "]";
	}
	
	
}

class DrivingLicense extends License
{
	String typeOfVehicle;
	int numberOfVehicle;
	 DrivingLicense()
	{
		System.out.println(" d() constructor");
	}
	public DrivingLicense(int licenseId, String name, char gender, String typeOfVehicle, int numberOfVehicle) {
		super(licenseId, name, gender);
		this.typeOfVehicle = typeOfVehicle;
		this.numberOfVehicle = numberOfVehicle;
	}
	@Override
	public String toString() {
		return "DrivingLicense [toString()=" + super.toString() + ", typeOfVehicle=" + typeOfVehicle
				+ ", numberOfVehicle=" + numberOfVehicle + "]";
	}
	
	
}





