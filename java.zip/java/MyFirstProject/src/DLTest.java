import java.time.LocalDate;

public class DLTest
{
	public static void main(String[] args) 
	{
		DrivingLicense dl1 = new DrivingLicense(1, "Ambika", 21, "Bike", LocalDate.of(2040, 8, 19));
		DrivingLicense dl2 = new DrivingLicense(2, "Dhondiba", 49, "Car", LocalDate.of(2034, 6, 17));
		DrivingLicense dl3 = new DrivingLicense(3, "Laxmi", 40, "Bike", LocalDate.of(2029, 2, 5));

		
		dl1.printDrivingLicense();
		dl2.printDrivingLicense();
		dl3.printDrivingLicense();
		
		System.out.println("---------------------------------------------");
		System.out.println("dl1 is stored at:"+dl1);
		System.out.println("dl2 is stored at:"+dl2);
		System.out.println("dl3 is stored at:"+dl3);
	}
}

class DrivingLicense 
{
	int drivingLicenseID;
	String holderName;
	int age;
	String typeOfVehicle;
	LocalDate expiryDate;

	public void setDrivingLicense(int a, String b, int c, String d, LocalDate e)
	{
		drivingLicenseID = a;
		holderName = b;
		age = c;
		typeOfVehicle = d;
		expiryDate = e;
	}
	

	public DrivingLicense(int drivingLicenseID, String holderName, int age, String typeOfVehicle,
			LocalDate expiryDate) {
		super();
		this.drivingLicenseID = drivingLicenseID;
		this.holderName = holderName;
		this.age = age;
		this.typeOfVehicle = typeOfVehicle;
		this.expiryDate = expiryDate;
	}
	


	public DrivingLicense(int drivingLicenseID, String holderName, int age, String typeOfVehicle) {
		super();
		this.drivingLicenseID = drivingLicenseID;
		this.holderName = holderName;
		this.age = age;
		this.typeOfVehicle = typeOfVehicle;
	}


	public void printDrivingLicense()
	{
		System.out.println("----------------------------------------------");
		System.out.println("license Id       :" + drivingLicenseID);
		System.out.println("Holder name      :" + holderName);
		System.out.println("age              :" + age);
		System.out.println("Type of Vehicle  :" + typeOfVehicle);
		System.out.println("Expiry Date      :" + expiryDate);
	}

	@Override
	public String toString() 
	{
		return "DrivingLicense [drivingLicenseID=" + drivingLicenseID + ", holderName=" + holderName + ", age=" + age
				+ ", typeOfVehicle=" + typeOfVehicle + ", expiryDate=" + expiryDate + "]";
	}
}
