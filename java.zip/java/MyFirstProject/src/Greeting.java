
public class Greeting {

	public static void main(String[] args) {
		
		System.out.println("Hello Java How Are You?");
		System.out.println("1.Java WORA");
		System.out.println("2.Java is simple");
		System.out.println("    no pointers, no memory management");
		System.out.println("3.Java is object oriented,OOPs");
		
	    Elephant e=new Elephant();
	    e.swimming();
	    Cat c=new Cat();
	    c.dancing();
	}

}
class Elephant
{
	void swimming() {
		System.out.println("elephant is swimming");
	}
}
class Cat
{
	void dancing() {
		System.out.println("cat is dancing");
	}
}