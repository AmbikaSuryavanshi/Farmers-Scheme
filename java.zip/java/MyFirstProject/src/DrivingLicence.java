
public class DrivingLicence {

	public static void main(String[] args) {
		Licence l=new Licence();
		l.authority();
		l.identity();
		l.idproof();
		Licence l1=new Licence();
		l1.authority();
		l1.identity();

	}

}
class Licence
{
	void authority()
	{
		System.out.println("getting authority");
	}
	void identity()
	{
		System.out.println("getting identity");
	}
	void idproof()
	{
		System.out.println("using as id proof");
	}
}