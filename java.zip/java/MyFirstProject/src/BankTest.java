
public class BankTest {

	public static void main(String[] args) {
		BankAccount ba1Ref1=new BankAccount();
		ba1Ref1.deposit(500);
		ba1Ref1.withdraw();
		BankAccount ba1Ref2=new BankAccount();
		ba1Ref2.deposit(150);

	}

}
class BankAccount
{
	void withdraw()
	{
		System.out.println("withdrawing....");
	}
	void deposit(float amount)
	{
		System.out.println("depositing...."+amount);
	}
}
