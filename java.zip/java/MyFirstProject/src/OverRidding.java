
public class OverRidding {

	public static void main(String[] args) {
		Dog dog = new Dog();
		dog.walking();
		dog.eating();
		dog.lifeTime();

		System.out.println("-----------------------------------");

		Rat rat = new Rat();
		rat.walking();
		rat.eating();
		rat.lifeTime();
		
		System.out.println("-----------------------------------");
		
		Bird bird=new Bird();
		bird.walking();
		bird.eating();
		bird.lifeTime();
		bird.flying();

	}

}

class Dog {
	void walking() {
		System.out.println("dog walk fastly");
	}

	void eating() {
		System.out.println("dog can eat more");
	}

	void lifeTime() {
		System.out.println("dog's lifetime is more");
	}
}

class Rat extends Dog {
	void walking() {
		System.out.println("rat walk slowly");
	}

	void eating() {
		System.out.println("rat can eat less compared to dog");
	}

	void lifeTime() {
		System.out.println("rat lifetime is less");
	}
	
}
class Bird extends Rat {
	void walking() {
		System.out.println("Bird walk slowly");
	}

	void eating() {
		System.out.println("Bird can eat less compared to Rat");
	}


	void lifeTime() {
		System.out.println("bird lifetime is less");
	}
	void flying() {
		System.out.println("bird can fly");
	}
}


