import java.time.LocalDate;
import java.time.LocalDateTime;

public class DataTypesTest {

	public static void main(String[] args) {

		byte rollNumber = 127;
		short universityRollNumber = 12345;
		int internationalRollNumber = 271637272;
		long galacticRollNumber = 1234432111;

		System.out.println("my roll number is             :" + rollNumber);
		System.out.println("my university roll number is  :" + universityRollNumber);
		System.out.println("my international rollnumber is:" + internationalRollNumber);
		System.out.println("my galactic rollnumber is     :" + galacticRollNumber);

		float interestRate = 1.23453F;
		double molecularDistance = 12.029f;
		System.out.println("interestrate is               :" + interestRate);
		System.out.println("molecualrdistance is          :" + molecularDistance);

		char myGender = 'f';
		System.out.println("my gender is                  :" + myGender);

		boolean areYouCertified = true;
		System.out.println("Are you certified?" + areYouCertified);

		String myName = "Ambika";
		String mySurName = "Suryavanshi";
		System.out.println("my name is:" + myName);
		System.out.println("my surname is:" + mySurName);
		
		LocalDate today=LocalDate.now();
		System.out.println("todays date is:"+today);
		LocalDateTime today1=LocalDateTime.now();
		System.out.println("todays date and time is:"+today1);
	}
}
