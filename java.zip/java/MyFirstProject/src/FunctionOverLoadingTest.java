
public class FunctionOverLoadingTest {

	public static void main(String[] args) {
		Phone myPhone=new Phone();
		myPhone.dial();
		myPhone.dial("Ambika");
		myPhone.dial(1223222233L);
		byte intercommNumber=120;
		myPhone.dial(intercommNumber);
		byte contryCode=112;
		myPhone.dial(contryCode,1234455333L);
		myPhone.dial(12983728L, contryCode);
		

	}

}
class Phone
{
	void dial() {
		System.out.println("dial() nowhere...");
	
	}
	void dial(byte intercommNumber) {
		System.out.println("dial(byte):dialing intercommNumber:"+intercommNumber);
	}
	void dial(String name) {
		System.out.println("dial(String):dialing by name:"+name);
	}
	void dial(long mobileNumber) {
		System.out.println("dial(long):dialing by mobile:"+mobileNumber);
	}
	void dial(byte countryCode,long mobileNumber) {
		System.out.println("dial(byte,long):dialing by countrycode:" +countryCode+ " mobileNumber:"+mobileNumber);
	}
	void dial(long mobileNumber,byte contryCode) {
		System.out.println("dial(long,byte):dialing by mobilenumber:"+mobileNumber+ " countrycode:"+contryCode);
	}
}