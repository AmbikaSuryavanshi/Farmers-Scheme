import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWritingTest {

	public static void main(String[] args) {
		try {
			FileOutputStream fout=new FileOutputStream("new.txt",true);
			System.out.println("file is ready for writing....");
			
			
			String str="This is the data written to the file\t ";
			byte barry[]=str.getBytes();
			System.out.println("string is coverted into byte array........");
			
			
			fout.write(barry);
			System.out.println("array is written to the file....");
			
			
			System.out.println("file is closing.....");
			fout.close();
			System.out.println("file is closed.....");
			
		} 
		 catch (FileNotFoundException e) {
				System.out.println("Handler1:"+e);
			}
			catch(IOException e)
			{
				System.out.println("Handler2:"+e);
			}
			

}
}
