import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileHandlingTest {
	public static void main(String[] args) {
		try {
			System.out.println("trying to open file.......");
			FileInputStream fin=new FileInputStream("C:\\Users\\ASI64\\Desktop\\New folder\\XYZ.txt");
			System.out.println("file id open.....");
			
			byte b=(byte) fin.read();
			while(b!=-1)
			{
				System.out.print((char)b);
				b=(byte) fin.read();
				Thread.sleep(3);
				
			}
			System.out.println("trying to close the file.....");
			fin.close();
			System.out.println("file closed..............");
		} catch (FileNotFoundException e) {
			System.out.println("Handler1:"+e);
		}
		catch(IOException e)
		{
			System.out.println("Handler2:"+e);
		}
		catch(InterruptedException e)
		{
			System.out.println("Handler3:"+e);
		}
		

	}

}
