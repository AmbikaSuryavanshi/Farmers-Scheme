import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MyFileReadingTest {
	public static void main(String[] args) {	
		
		MyFileReader mfr1 = new MyFileReader("C:\\\\Users\\\\ASI64\\\\Desktop\\\\New folder\\\\XYZ.txt");
		MyFileReader mfr2 = new MyFileReader("C:\\Users\\ASI64\\Desktop\\New folder\\\\wxy.txt");
		MyFileReader mfr3 = new MyFileReader("C:\\Users\\ASI64\\Desktop\\New folder\\\\mno.txt");
		
		mfr1.readFile();
		System.out.println("---------------------------------------------");
		mfr2.readFile();
		System.out.println("---------------------------------------------");
		mfr3.readFile();
		
		mfr1.closeFile();
		mfr2.closeFile();
		mfr3.closeFile();
		
		
		
	}
}
class MyFileReader {
	FileInputStream fin;
	public MyFileReader(String filename) {
		try { fin = new FileInputStream(filename);} 
		catch (FileNotFoundException e) {e.printStackTrace();}
	}	
	void readFile() {
		try {
			byte b= (byte) fin.read(); 	
			while(b!=-1) {
				System.out.print((char)b); 
				b = (byte) fin.read();
				Thread.sleep(3);
			}			
		} catch (IOException e) 
		{
			System.out.println("Handler2 :"+e);
			} 
		catch (InterruptedException e)
		{
			System.out.println("Handler3 :"+e);
			}
	}	
	void closeFile() {
		try
		{
			fin.close();
			} 
		catch (IOException e)
		{
			e.printStackTrace();
			}
	}
}
