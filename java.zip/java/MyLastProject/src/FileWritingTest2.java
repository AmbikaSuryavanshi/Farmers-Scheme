import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FileWritingTest2 {
	public static void main(String[] args) {
		Myframe mfr=new Myframe();
		mfr.setVisible(true);
}
}

class Myframe extends JFrame implements ActionListener
{
	JLabel label1=new JLabel("enter filename");
	JTextField  filename=new JTextField(20);
	
	JLabel label2=new JLabel("enter data");
	JTextArea dataArea=new JTextArea(15,30);
	
	JButton save=new JButton("save");
	JButton clear=new JButton("clear");
	
	Myframe()
	{
		  setLayout(new FlowLayout()); setSize(900,300); setLocation(100,100);
		  setTitle("My Notepad"); add(label1); add(filename); add(label2);
		  add(dataArea); add(save); add(clear);
		  save.addActionListener(this);
		  clear.addActionListener(this);
		  
		 
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource()==save)
		{
			System.out.println("save button is clicked.........");
		try {
			FileOutputStream fout=new FileOutputStream(filename.getText(),true);
			System.out.println("file is ready for writing....");
			
			byte barry[]=dataArea.getText().getBytes();
			System.out.println("string is coverted into byte array........");
			
			
			fout.write(barry);
			System.out.println("array is written to the file....");
			
			JOptionPane.showMessageDialog(this,"File is Saved");
			
			System.out.println("file is closing.....");
			fout.close();
			System.out.println("file is closed.....");
			
		} 
		 catch (FileNotFoundException e) {
			 e.printStackTrace();
			 JOptionPane.showMessageDialog(this, e.getMessage());
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
	}
		else
		{
			System.out.println("clear button is clicked.........");
			JOptionPane.showMessageDialog(this,"File is cleared");
		}
	}
}






























