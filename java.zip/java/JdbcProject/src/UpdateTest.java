import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateTest {
	public static void main(String[] args) {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			System.out.println("1. driver...loaded");

			System.out.println("Trying to connect to the DB...");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "root123");
			System.out.println("2. Connected to the DB :" + conn);

			PreparedStatement pst = conn.prepareStatement("update employee set empname=? , job=? , salary=? where empno=?");
			System.out.println("3. Prepared Statement created....");
			
			pst.setString(1, "AMBIKA");
			pst.setString(2,"MANAGER");
			pst.setInt(3, 2024);
			pst.setInt(4, 120);
			
			int rows=pst.executeUpdate();
			  
		 System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
	     System.out.println("6. db resources closed....");
	     pst.close();
	     conn.close();
		 System.out.println("DB resources are closed...");
			 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
