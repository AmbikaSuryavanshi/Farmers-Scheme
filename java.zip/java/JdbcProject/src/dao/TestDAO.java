package dao;

import java.util.List;

public class TestDAO {

	public static void main(String[] args) {
		EmployeeDAOImpl empDaoImpl=new EmployeeDAOImpl();
		employee.setEmployeeNumber(result.getInt(1));
	  	employee.setEmployeeName( result.getString(2));
	  	employee.setEmployeeJob(result.getString(3));
	  	employee.setEmployeeSalary(result.getInt(4));
	  	emplist.add(employee); 
		
		/*
		 * List<Employee> empList = empDaoImpl.getEmployees();
		 * 
		 * for (Employee employee : empList) { System.out.println("Emp : "+employee); }
		 */
		
		/*
		 * Employee employee=new Employee(); employee.setEmployeeNumber(107);
		 * employee.setEmployeeName("Surendr"); employee.setEmployeeJob("Developer");
		 * employee.setEmployeeSalary(55000);
		 * 
		 * empDaoImpl.addEmployee(employee);
		 */
			
		

}
}
	
