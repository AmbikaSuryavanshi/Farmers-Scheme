
public class ExceptionTest {

	public static void main(String[] args) {
		Calculator calci = new Calculator();
		calci.divide1(120, 5);
		System.out.println("---------------------");
		calci.divide2(130, 0);
		System.out.println("---------------------");
		calci.divide3("Eight", "Two");
	}

}

class Calculator
{
	void divide1(int num, int denom) 
	{
		System.out.println("num:" + num);
		System.out.println("denom:" + denom);
		if (denom != 0) 
		{
			int div = num / denom;
			System.out.println("div:" + div);
		} 
		else 
		{
			System.out.println("not a number");
		}
	}
	
	
	

	void divide2(int num, int denom)
	{
		System.out.println("num:" + num);
		System.out.println("denom:" + denom);
		try 
		{
			int div = num / denom;
			System.out.println("div:" + div);
		} 
		catch (ArithmeticException e)
		{
			System.out.println("not a number..............");
		}
	}
	
	
	
	
	void divide3(String num, String denom)
	{
		System.out.println("num:" + num);
		System.out.println("denom:" + denom);
		try 
		{
			int x=Integer.parseInt(num);
		    int y=Integer.parseInt(denom);
			int div = x /y;
			System.out.println("div:" + div);
		} 
		catch (NumberFormatException e)
		{
			System.out.println("please supply a number.......................");
		}
	}
	
}