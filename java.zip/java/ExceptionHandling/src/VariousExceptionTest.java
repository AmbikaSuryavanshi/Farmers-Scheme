import java.util.Arrays;

public class VariousExceptionTest {

	public static void main(String[] args) {
		try
		{
			
			int scores[]= {89,17,45,37,54};
			System.out.println("score:"+Arrays.toString(scores));
			System.out.println("score[0]     :"+scores[0]);
			System.out.println("score[1]     :"+scores[1]);
			System.out.println("score[2]     :"+scores[2]);
			System.out.println("score[3]     :"+scores[3]);
			System.out.println("score[4]     :"+scores[4]);
			System.out.println("----------------------------------------------");
			String str="Dassault_Systemes";
			System.out.println("str          :"+str);
			System.out.println("str cap      :"+str.toUpperCase());
			System.out.println("str low      :"+str.toLowerCase());
			System.out.println("str charAt   :"+str.charAt(6));
			System.out.println("substring    :"+str.substring(1,10));
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Arrays index is invalid");
		}
		catch(NullPointerException e)
		{
			System.out.println("string is null");
		}
		catch(StringIndexOutOfBoundsException e)
		{
			System.out.println("string index is invalid");
		}

	}

}
