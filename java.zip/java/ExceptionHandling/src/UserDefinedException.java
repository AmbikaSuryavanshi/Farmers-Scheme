
public class UserDefinedException {

	public static void main(String[] args) {
		Person person = new Person();
		try {
			person.shower();
		} catch (NoWaterException e) {
			System.out.println("Handler3 :" + e);
		} catch (WaterTooColdException e) {
			System.out.println("Handler1 :" + e);
		} catch (WaterTooHotException e) {
			System.out.println("Handler2 :" + e);
		} catch (SlipAndFallException e) {
			System.out.println("Handler4 :" + e);
		} finally {
			System.out.println("finally shower is over.........");

		}
	}
}

class Person {
	void shower() throws NoWaterException
	{
		System.out.println("inside the Washroom..........");
		double d = Math.random() % 10;
		if (d < 0.10) {
			NoWaterException rte = new NoWaterException("there is no water.........");
			throw rte;
		} else {
			System.out.println("\tbegin Shower...............");
			for (int i = 0; i < 20; i++) {
				System.out.println("\t\tShower is going on........" + i);
				if (d > 0.80 && d < 0.99) {
					WaterTooHotException wte = new WaterTooHotException("water is Too Hot..........");
					throw wte;
				} else if (d < 0.30 && d > 0.20) {
					WaterTooColdException wtc = new WaterTooColdException("water is too cold.....");
					throw wtc;
				} else if (d > 0.40 && d < 0.55) {
					SlipAndFallException sfe = new SlipAndFallException(" slip and fell down.........");
					throw sfe;
				}
			}
			System.out.println("\tend of shower........");
		}
		System.out.println("exiting the washroom...........");

	}
}

class WaterTooHotException extends RuntimeException {

	public WaterTooHotException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

class WaterTooColdException extends RuntimeException {

	public WaterTooColdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

class NoWaterException extends RuntimeException {

	public NoWaterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

class SlipAndFallException extends RuntimeException {

	public SlipAndFallException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
