import Myself.relative.Uncle;

public class PackageTest {

	public static void main(String[] args) {
	   Uncle uncle=new Uncle();
	   uncle.probingUncle();

	}

}
