package Myself;

public class Father {

		           int goldchain=12;
		public     int pf=31;
		private    int vehicles=2;
		protected  int someproperty =4;
		
		void myDetails()
		{
			System.out.println("goldchain    :"+goldchain);
			System.out.println("pf           :"+pf);
			System.out.println("vehicles     :"+vehicles);
			System.out.println("someproperty :"+someproperty);
		}
	}


