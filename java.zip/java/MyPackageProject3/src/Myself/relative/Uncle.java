package Myself.relative;

import Myself.Father;

public class Uncle {

	public void probingUncle() {
		  Father f=new Father();
		//System.out.println("goldchain    :"+f.goldchain);
		  System.out.println("pf           :"+f.pf);
		//System.out.println("vehicles     :"+f.vehicles);
		//System.out.println("someproperty :"+f.someproperty);
	}

}
class Child extends Father
{
	void probing()
	{

		System.out.println("goldchain    :"+goldchain);
		System.out.println("pf           :"+pf);
		System.out.println("vehicles     :"+vehicles);
		System.out.println("someproperty :"+someproperty);
}
}
