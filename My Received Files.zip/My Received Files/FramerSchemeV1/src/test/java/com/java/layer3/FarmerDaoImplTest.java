package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.Farmer;



public class FarmerDaoImplTest {
	@Test
	public void testAllFarmers()
	{
		System.out.println("started DAO testing...");
		
	IFarmerDAO farmerDao= new FarmerDAOImpl();
	
		
	Assertions.assertTrue(farmerDao!=null);
		
		List<Farmer> farmerList=farmerDao.selectAllFarmers();
	Assertions.assertTrue(farmerList.size() > 0 );
		
		for (Farmer farmer : farmerList) {
			System.out.println("Farmer : "+farmer);
		}
	
	}
	

	

}
