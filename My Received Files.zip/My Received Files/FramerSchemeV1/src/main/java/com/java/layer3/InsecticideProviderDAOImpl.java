package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.java.layer2.InsecticideProvider;

public class InsecticideProviderDAOImpl implements IInsecticideProviderDAO {
	Connection conn;

	public InsecticideProviderDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public InsecticideProvider selectInsecticideProvider(long InsecticideProviderId) {
		
		
        InsecticideProvider insecticideprovider = null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result= statement.executeQuery("SELECT*from InsecticideProvider where InsecticideProviderId="+InsecticideProviderId);
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			if(result.next())
			{
				insecticideprovider= new InsecticideProvider();
				insecticideprovider.setInsecticideProviderId(result.getLong(1));
				insecticideprovider.setInsecticideProviderName(result.getString(2));
				insecticideprovider.setContact(result.getLong(3));
				insecticideprovider.setEmail(result.getString(4));
				insecticideprovider.setCompanyName(result.getString(5));
				insecticideprovider.setInsecticideProviderRating(6);
				
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return insecticideprovider;
		
	}

	@Override
	public List<InsecticideProvider> selectAllInsecticideProvider() {
	 List<InsecticideProvider> InsecticideProviderList = new ArrayList<InsecticideProvider>();
	 
	 try {
		Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsecticideProvider"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			while(result.next())
			{
				InsecticideProvider insecticideprovider= new InsecticideProvider();
				insecticideprovider.setInsecticideProviderId(result.getLong(1));
				insecticideprovider.setInsecticideProviderName(result.getString(2));
				insecticideprovider.setContact(result.getLong(3));
				insecticideprovider.setEmail(result.getString(4));
				insecticideprovider.setCompanyName(result.getString(5));
				insecticideprovider.setInsecticideProviderRating(result.getFloat(6));
				InsecticideProviderList.add(insecticideprovider);
				
			}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return InsecticideProviderList;
	}

	@Override
	public void insertInsecticideProvider(InsecticideProvider insecticideprovider) {
	
		try {
			PreparedStatement pst = conn.prepareStatement("insert into InsecticideProvider(InsecticideProviderId,InsecticideProviderName,Contact,Email,CompanyName,InsecticideProviderRating) values(?,?,?,?,?,?)");
			System.out.println("3. PreparedStatement created....");
			pst.setLong(1, insecticideprovider.getInsecticideProviderId());
			pst.setString(2, insecticideprovider.getInsecticideProviderName());
			pst.setLong(3, insecticideprovider.getContact());
			pst.setString(4, insecticideprovider.getEmail());
			pst.setString(5, insecticideprovider.getCompanyName());
			pst.setFloat(6, insecticideprovider.getInsecticideProviderRating());
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateInsecticideProvider(InsecticideProvider insecticideprovider) {
		try {
			PreparedStatement pst= conn.prepareStatement("update InsecticideProvider InsecticideProviderId=?,InsecticideProviderName=?,Contact=?,Email=?,CompanyName=?,InsecticideProviderRating=?");
			System.out.println("Prepared statement created");
			pst.setLong(1, insecticideprovider.getInsecticideProviderId());
			pst.setString(2, insecticideprovider.getInsecticideProviderName());
			pst.setLong(3,insecticideprovider.getContact());
			pst.setString(4,insecticideprovider.getEmail());
			pst.setString(5,insecticideprovider.getCompanyName());
			pst.setFloat(6,insecticideprovider.getInsecticideProviderRating());
			int rows= pst.executeUpdate();
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void deleteInsecticideProvider(long InsecticideProviderId) {
		
		try {
			PreparedStatement pst = conn.prepareStatement("delete from InsecticideProvider where InsecticideProviderId=?");
			System.out.println("3. PreparedStatement created....");
			pst.setLong(1, InsecticideProviderId);
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
