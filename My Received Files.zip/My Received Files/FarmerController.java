package com.java.layer5;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.CropForSale;
import com.java.layer2.Farmer;
import com.java.layer4.FarmerAlreadyExistsException;
import com.java.layer4.FarmerNotExistsException;
import com.java.layer4.FarmerService;
import com.java.layer4.FarmerServiceImpl;

@Path("/farmer")
public class FarmerController {
	FarmerService farmerService=new FarmerServiceImpl();
	
	public FarmerController() { System.out.println("Currency Service called...");}
	
	@GET
	@Path("/greet")
	public String greet() {
		return "<h1>Greetings to the Farmer</h1>";
				
	}
	@POST
	@Path("/addFarmer")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addFarmer(Farmer f) {
		try {
			farmerService.saveFarmerService(f);
			List<Farmer> farmerList = farmerService.findAllAllFarmersService();
			return Response
					.status(Response.Status.OK)
					.entity(farmerList)
					.build();
		}
		catch(FarmerAlreadyExistsException err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	
	
	@PUT
	@Path("/updateFarmer")
	@Produces(MediaType.APPLICATION_JSON)
	public Response ModifyIt(Farmer fObj)
	{
		try
		{
			farmerService.modifyFarmerService(fObj);
			List<Farmer> farmerList = farmerService.findAllAllFarmersService();
			return Response
					.status(Response.Status.OK)
					.entity(farmerList)
					.build();
		}
		catch(FarmerNotExistsException e)
		{
			System.out.println(e);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
		
	}
	
	

	@GET
	@Path("/all/{farmerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getBidder(@PathParam("farmerId") long bidderId) {
		try {
			Farmer farmer = farmerService.findFarmerService(bidderId);
			return Response
					.status(Response.Status.OK)
					.entity(farmer)
					.build();
		}
		catch(FarmerNotExistsException err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response allFarmers(){
		try {
			List<Farmer> farmerList = farmerService.findAllAllFarmersService();
			return Response
					.status(Response.Status.OK)
					.entity(farmerList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/allCrop/{farmerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCropForSale(@PathParam("farmerId") long farmerId) {
		try {
			List<CropForSale> crop = farmerService.findCropForSale(farmerId);
			return Response
					.status(Response.Status.OK)
					.entity(crop)
					.build();
		}
		catch(FarmerNotExistsException err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@POST
	@Path("/addCropForSale")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addCropForSale(CropForSale c) {
		
		
		try {
			farmerService.AddCropForSale(c);
			List<CropForSale>  cropList = farmerService.findCropForSale(c.getFarmerId());
			return Response
					.status(Response.Status.OK)
					.entity(cropList)
					.build();
		} catch ( Exception e) {
			System.out.println(e);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
		
	}
	
	@PUT
	@Path("/updateCropForSale")
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateCropForSale(CropForSale c) {
		try {
			farmerService.modifyCropForSaleFarmer(c);
			List<CropForSale>  cropList = farmerService.findCropForSale(c.getFarmerId());
			return Response
					.status(Response.Status.OK)
					.entity(cropList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@DELETE
	@Path("/deleteFarmer/{farmerId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteBidder(@PathParam("farmerId") long farmerId) {
		try {
			farmerService.removeFarmerService(farmerId);
			List<Farmer> bidderList = farmerService.findAllAllFarmersService();
			return Response
					.status(Response.Status.OK)
					.entity(bidderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	

}
