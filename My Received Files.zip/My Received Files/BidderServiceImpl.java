package com.java.layer4;

import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Bid;
import com.java.layer2.Bidder;
import com.java.layer2.Crop;
import com.java.layer2.CropForSale;
import com.java.layer2.SuccessfulTransaction;
import com.java.layer3.BidDAOImpl;
import com.java.layer3.BidderDAOImpl;
import com.java.layer3.CropDAOImpl;
import com.java.layer3.CropForSaleDAOImpl;
import com.java.layer3.IBidDAO;
import com.java.layer3.IBidderDAO;
import com.java.layer3.ICropDAO;
import com.java.layer3.ICropForSaleDAO;
import com.java.layer3.ISuccessfulTransactionDAO;
import com.java.layer3.SuccessfulTransactionDAOImpl;

public class BidderServiceImpl implements IBidderService {

	public BidderServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Bidder> findAllBidderService() {
		// TODO Auto-generated method stub
		IBidderDAO bidderDao =  new BidderDAOImpl();
		List<Bidder> bidderList = bidderDao.selectAllBidders();
		return bidderList;
	}

	@Override
	public Bidder findBidderService(long bidderId) {
		// TODO Auto-generated method stub
		IBidderDAO bidderDao =  new BidderDAOImpl();
		Bidder b = new Bidder();
		b = bidderDao.selectBidder(bidderId);
		
		System.out.println("inside bidder service....");
		
		return b;
	}

	@Override
	public void insertBidderService(Bidder b) {
		// TODO Auto-generated method stub
		IBidderDAO bidderDao =  new BidderDAOImpl();
		bidderDao.insertBidder(b);
	}

	@Override
	public void removeBidderService(long bidderId) {
		// TODO Auto-generated method stub
		IBidderDAO bidderDao = new BidderDAOImpl();
		bidderDao.deleteBidder(bidderId);
	}

	@Override
	public void modifyBidderService(Bidder b) {
		// TODO Auto-generated method stub
		IBidderDAO bidderDao = new BidderDAOImpl();
		bidderDao.updateBidder(b);

	}

	@Override
	public List<CropForSale> showAllCropForSaleService() {
		// TODO Auto-generated method stub
		ICropForSaleDAO cropForSaleDao = new CropForSaleDAOImpl();
		IBidDAO bidDao = new BidDAOImpl();
		ICropDAO cropDao = new CropDAOImpl();
		List<CropForSale> cropForSaleList = cropForSaleDao.selectAllCropsForSale();
		List<Crop> crops = cropDao.selectAllCrops();
		
		List<Bid> allBids = bidDao.selectAllBids();
		
		for (CropForSale cropForSale : cropForSaleList) {
			float maxAmount = cropForSale.getMinimumPrice();
			
			for (Bid bid : allBids) {
				if(Long.compare(bid.getCropForSaleId(),cropForSale.getCropForSaleId())==0) {
					maxAmount = Math.max(maxAmount, bid.getAmount());
				}
			}
			
			cropForSale.setMinimumPrice(maxAmount);
			
		}
		
		for (CropForSale cropForSale : cropForSaleList) {
			for(Crop crop : crops) {
				if(crop.getCropId()==cropForSale.getCropId()) {
					cropForSale.setCropName(crop.getCropName());
				}
			}
		}
		
		
		return cropForSaleList;
	}

	@Override
	public List<SuccessfulTransaction> showAllBidderTransactionService(long bidderId) {
		// TODO Auto-generated method stub
		ISuccessfulTransactionDAO successfulTransactionDao = new SuccessfulTransactionDAOImpl();
		IBidDAO bidDao = new BidDAOImpl();
		List<Bid> bids = bidDao.selectAllBids(); 
		List<Bid> bidsRes = new ArrayList<Bid>();
		
		
		for (Bid bid : bids) {
			if(Long.compare(bid.getBidderId(), bidderId)==0) {
				bidsRes.add(bid);
			}
		}
		
		
		List<SuccessfulTransaction> successfulTransactions = successfulTransactionDao.selectAllTransactions();
		List<SuccessfulTransaction> successfulTransactionRes = new ArrayList<SuccessfulTransaction>();
		
		for (SuccessfulTransaction successfulTransaction : successfulTransactions) {
			for (Bid bidRes : bidsRes) {
				if(Long.compare(bidRes.getBidderId(), bidderId)==0 && 
						Long.compare(bidRes.getBidId(), successfulTransaction.getBidId())==0) {
					successfulTransactionRes.add(successfulTransaction);
				}
			}
		}
		
		return successfulTransactionRes;
		
	}

	@Override
	public void doBid(long bidderId, long cropForSaleId, float amount) {
		// TODO Auto-generated method stub
		IBidDAO bidDao = new BidDAOImpl();
		ICropForSaleDAO cropForSaleDao = new CropForSaleDAOImpl();
		List<Bid> allBids = bidDao.selectAllBids();
		List<CropForSale> allCropForSale = cropForSaleDao.selectAllCropsForSale();
		
		float minAmount = 0;
		
		for(CropForSale cropForSale:allCropForSale) {
			if(Long.compare(cropForSale.getCropForSaleId(), cropForSaleId)==0) {
				minAmount = Math.max(minAmount, cropForSale.getMinimumPrice());
			}
		}
		
		for(Bid bid:allBids) {
			if(Long.compare(cropForSaleId, bid.getCropForSaleId())==0) {
				minAmount = Math.max(minAmount, bid.getAmount());
			}
		}
		
		if(amount>minAmount) {
			bidDao.insertBid(new com.java.layer2.Bid(0L, bidderId, cropForSaleId, amount));			
		}
		else {
			System.out.println("Enter a higher value");
		}
		
	}
	
	public Bid getBid(long bidId) {
		IBidDAO bidDao =  new BidDAOImpl();
		
		Bid res = null;
		
		List<Bid> bids = bidDao.selectAllBids();
		
		for (Bid bid : bids) {
			if(Long.compare(bid.getBidId(), bidId)==0 ) {
				res = bid;
			}
		}
		
		return res;
	}
	
	public List<Bid> getBids(long bidderId) {
		IBidDAO bidDao = new BidDAOImpl();
		List<Bid> bids = bidDao.selectAllBids();
		List<Bid> res = new ArrayList<Bid>();
		
		for (Bid bid : bids) {
			if(Long.compare(bidderId, bid.getBidderId())==0) {
				res.add(bid);
			}
		}
		
		return res;
	}
	
	
	

}
