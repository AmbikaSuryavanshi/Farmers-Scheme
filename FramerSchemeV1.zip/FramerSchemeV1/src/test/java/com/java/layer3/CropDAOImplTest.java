package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.Crop;


public class CropDAOImplTest {
	
		@Test
		public void testAllCrops()
		{
			System.out.println("started DAO testing...");
			
		ICropDAO cropDao = new CropDAOImpl();
		
			
		Assertions.assertTrue(cropDao!=null);
			
			List<Crop> cropList=cropDao.selectAllCrops();
		Assertions.assertTrue(cropList.size() > 0 );
			
			for (Crop crop : cropList) {
				System.out.println("Crop : "+crop);
			}
		
		}
		
		public void testCrop() {
			System.out.println("started DAO testing...");
		}
		


}

