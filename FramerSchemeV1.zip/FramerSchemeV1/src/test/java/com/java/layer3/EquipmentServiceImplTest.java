package com.java.layer3;

import java.util.List;


import org.junit.jupiter.api.Test;

import com.java.layer2.Equipment;
import com.java.layer4.EquipmentAlreadyExistsException;

import com.java.layer4.EquipmentService;
import com.java.layer4.EquipmentServiceImpl;



public class EquipmentServiceImplTest {
	EquipmentService eqpserv=new EquipmentServiceImpl();

	@Test
	public void equipmentAddTest()
	{
	Equipment equipment= new Equipment();
	equipment.setEquipmentId(4);
	equipment.setEquipmentName("baran");
	equipment.setPrice(50);
	try {
	eqpserv.saveEquipmentService(equipment);
	}
	catch(EquipmentAlreadyExistsException e) {
		System.out.println("error:"+e);
	}
	}
}
	



