package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.Equipment;



public class EquipmentDAOImplTest {
	

	@Test
	public void testAllEquipments()
	{
		System.out.println("started DAO testing...");
		
		IEquipmentDAO eqpDao = new EquipmentDAOImpl();
		
	Assertions.assertTrue(eqpDao!=null);
		
		List<Equipment> eqpList=eqpDao.selectAllEquipments();
	Assertions.assertTrue(eqpList.size() > 0 );
		
		for (Equipment equipment : eqpList) {
			System.out.println("Equipment : "+equipment);
		}
	
	}
	
	@Test
	public void testLoadSingleEquipment()
	{
		System.out.println("started DAO testing...");
		
		IEquipmentDAO eqpDao = new EquipmentDAOImpl();
		
	Assertions.assertTrue(eqpDao!=null);
		
		Equipment eqp=eqpDao.selectEquipment(1);
	Assertions.assertTrue(eqp!=null );
		
		System.out.println("Equipment : "+eqp);
	
	}
	
	@Test
	public void testAddSingleEquipment()
	{
		System.out.println("started DAO testing...");
		
		IEquipmentDAO eqpDao = new EquipmentDAOImpl();	
	Assertions.assertTrue(eqpDao!=null);
		
		Equipment eqp=new Equipment();
	Assertions.assertTrue(eqp!=null);
	
	
		eqp.setEquipmentId(5);
		eqp.setEquipmentName("Cultivator");
		eqp.setPrice(20000);
		
		System.out.println("Equipment : "+eqp);
		eqpDao.insertEquipment(eqp);
		System.out.println("Equipment added....");
	}
	
	@Test
	public void testUpdateSingleEquipment()
	{
		System.out.println("started DAO testing...");
		
		IEquipmentDAO eqpDao = new EquipmentDAOImpl();
	Assertions.assertTrue(eqpDao!=null);
		
	Equipment eqp=new Equipment();
	Assertions.assertTrue(eqp!=null);
		
		eqp.setEquipmentId(1);
		eqp.setEquipmentName("Harvester");
		eqp.setPrice(10000);
		
		System.out.println("Equipment : "+eqp);
		eqpDao.updateEquipment(eqp);
		System.out.println("Equipment updated....");
	}
	
	@Test
	public void testDeleteSingleEquipment()
	{
		System.out.println("started DAO testing...");
		
		IEquipmentDAO eqpDao = new EquipmentDAOImpl();	
	Assertions.assertTrue(eqpDao!=null);
		
		eqpDao.deleteEquipment(4);
		System.out.println("Equipment deleted....");
	}
	
	
	
}
