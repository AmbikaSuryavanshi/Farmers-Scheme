package com.java.layer4;





import org.junit.jupiter.api.Test;

import com.java.layer2.Equipment;




public class EquipmentServiceImplTest {
	EquipmentService eqpserv=new EquipmentServiceImpl();

	@Test
	public void equipmentAddTest()
	{
	Equipment equipment= new Equipment();
	equipment.setEquipmentId(4);
	equipment.setEquipmentName("baran");
	equipment.setPrice(50);
	try {
	eqpserv.saveEquipmentService(equipment);
	}
	catch(EquipmentAlreadyExistsException e) {
		System.out.println("error:"+e);
	}
	}
	

	@Test
	public void equipmentmodifyTest()
	{
	Equipment equipment= new Equipment();
	equipment.setEquipmentId(9);
	
	try {
	eqpserv.modifyEquipmentService(equipment);
	}
	catch(EquipmentNotFoundException e) {
		System.out.println("error:"+e);
	}
	}
}
	


	
	
	

