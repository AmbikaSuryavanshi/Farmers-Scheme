package com.java.layer4;

import org.junit.jupiter.api.Test;


import com.java.layer2.EquipmentProvider;

public class EquipmentProviderServiceImplTest {
	EquipmentProviderService eqpprovserv=new EquipmentProviderServiceImpl();

	@Test
	public void equipmentProviderAddTest()
	{
	EquipmentProvider equipmentProvider= new EquipmentProvider();
	equipmentProvider.setEquipmentProviderId(4443189651342l);
	equipmentProvider.setEquipmentProviderName("Karan");
	equipmentProvider.setContact(9321897761l);
	equipmentProvider.setEmailId("karan@gmail.com");
	equipmentProvider.setCompanyName("SayiFarmCrafts");
	equipmentProvider.setEquipmentProviderRating(4.8f);

	try {
		eqpprovserv.saveEquipmentProviderService(equipmentProvider);
		
	} catch (EquipmentProviderAlreadyExistsException e) {
		System.out.println("error:"+e);
	}

	}
	

	@Test
	public void equipmentProvidermodifyTest()
	{
	EquipmentProvider equipmentprovider= new EquipmentProvider();
	equipmentprovider.setEquipmentProviderId(467245318901l);
	
	try {
		eqpprovserv.modifyEquipmentProviderService(equipmentprovider);
	} catch (EquipmentProviderNotFoundException e) {
		System.out.println("error:"+e);
	}
	}
}
	
	

