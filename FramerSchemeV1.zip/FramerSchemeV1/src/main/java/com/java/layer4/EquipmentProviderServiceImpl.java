package com.java.layer4;

import java.util.List;


import com.java.layer2.EquipmentProvider;

import com.java.layer3.EquipmentProviderDAOImpl;

import com.java.layer3.IEquipmentProviderDAO;

public class EquipmentProviderServiceImpl implements EquipmentProviderService{

	public EquipmentProviderServiceImpl() {
		System.out.println("EquipmentProviderService Constructor()..................");
	}
	
	IEquipmentProviderDAO eqpprovDao=new EquipmentProviderDAOImpl();
	@Override
	public void saveEquipmentProviderService(EquipmentProvider equipmentProviderToAdd)
			throws EquipmentProviderAlreadyExistsException {
		List<EquipmentProvider> listequipmentProviders = eqpprovDao.selectAllequipmentProviders();
		boolean equipmentProviderFound=false;	
		for (EquipmentProvider equipmentProvider : listequipmentProviders) {
			if(Long.compare(equipmentProvider.getEquipmentProviderId(),equipmentProviderToAdd.getEquipmentProviderId())==0){
					equipmentProviderFound=true;	
					break;
			} 
		}
		if(equipmentProviderFound==true)throw new EquipmentProviderAlreadyExistsException("EquipmentProvider Already present");
		else eqpprovDao.insertEquipmentProvider(equipmentProviderToAdd);
		
	}

	@Override
	public void modifyEquipmentProviderService(EquipmentProvider equipmentProviderToModify)
			throws EquipmentProviderNotFoundException {
		List<EquipmentProvider> listequipmentProviders = eqpprovDao.selectAllequipmentProviders();
		boolean equipmentProviderFound=false;	
		for (EquipmentProvider equipmentProvider : listequipmentProviders) {
			if(equipmentProvider.getEquipmentProviderId() == equipmentProviderToModify.getEquipmentProviderId() ) {
					equipmentProviderFound=true;	
					break;
			} 
		}
		if(equipmentProviderFound==false)throw new EquipmentProviderNotFoundException("EquipmentProvider Not present");
		else eqpprovDao.updateEquipmentProvider(equipmentProviderToModify);
		
	}

	@Override
	public EquipmentProvider findEquipmentProviderService(long equipmentproviderId)
			throws EquipmentProviderNotFoundException {
		EquipmentProvider eq= new EquipmentProvider();
		List<EquipmentProvider> listequipmentProviders = eqpprovDao.selectAllequipmentProviders();
		boolean equipmentProviderFound=false;	
		for (EquipmentProvider equipmentProvider : listequipmentProviders) {
			if(equipmentProvider.getEquipmentProviderId()== equipmentproviderId) {
				    eq= eqpprovDao.selectEquipmentProvider(equipmentproviderId);
					equipmentProviderFound=true;	
					break;
			} 
		}
		if(equipmentProviderFound==false)
			throw new EquipmentProviderNotFoundException("EquipmentProvider Not present");
		else
			return eq;
	}

	@Override
	public List<EquipmentProvider> findAllAllEquipmentProvidersService() {
		IEquipmentProviderDAO eqpDao =  new EquipmentProviderDAOImpl();
		List<EquipmentProvider> listequipmentproviders = eqpDao.selectAllequipmentProviders();
		return listequipmentproviders;
	}

}
