package com.java.layer4;

public class EquipmentAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EquipmentAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	}

