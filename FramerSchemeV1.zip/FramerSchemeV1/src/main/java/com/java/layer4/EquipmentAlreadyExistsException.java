package com.java.layer4;

public class EquipmentAlreadyExistsException extends Exception {

	public EquipmentAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	}

