package com.java.layer4;



import java.util.List;



import com.java.layer2.Equipment;
import com.java.layer2.EquipmentProvider;
import com.java.layer3.EquipmentDAOImpl;
import com.java.layer3.IEquipmentDAO;

public class EquipmentServiceImpl implements EquipmentService {
	
	public EquipmentServiceImpl() {
		System.out.println("EquipmentService Constructor()..................");
	}
	
	IEquipmentDAO eqpDao=new EquipmentDAOImpl();
	public void saveEquipmentService(Equipment equipmentToAdd) throws EquipmentAlreadyExistsException {
		List<Equipment> listequipments = eqpDao.selectAllEquipments();
		boolean equipmentFound=false;	
		for (Equipment equipment : listequipments) {
			if(equipment.getEquipmentId()==equipmentToAdd.getEquipmentId() ){
					equipmentFound=true;	
					break;
			} 
		}
		if(equipmentFound==true)throw new EquipmentAlreadyExistsException("Equipment Already present");
		else eqpDao.insertEquipment(equipmentToAdd);
	}

	

	@Override
	public void modifyEquipmentService(Equipment equipmentToModify) throws EquipmentNotFoundException {
		List<Equipment> listequipments = eqpDao.selectAllEquipments();
		boolean equipmentFound=false;	
		for (Equipment equipment : listequipments) {
			if(equipment.getEquipmentId() == equipmentToModify.getEquipmentId() ) {
					equipmentFound=true;	
					break;
			} 
		}
		if(equipmentFound==false)throw new EquipmentNotFoundException("Equipment Not present");
		else eqpDao.updateEquipment(equipmentToModify);
	}


	@Override
	public Equipment findEquipmentService(int equipmentId)
			throws EquipmentNotFoundException {
		Equipment eq= new Equipment();
		List<Equipment> listequipments = eqpDao.selectAllEquipments();
		boolean equipmentFound=false;	
		for (Equipment equipment : listequipments) {
			if(equipment.getEquipmentId()== equipmentId) {
				    eq= eqpDao.selectEquipment(equipmentId);
					equipmentFound=true;	
					break;
			} 
		}
		if(equipmentFound==false)
			throw new EquipmentNotFoundException("Equipment Not present");
		else
			return eq;
	}
		



	@Override
	public List<Equipment> findAllAllEquipmentsService() {
		IEquipmentDAO eqpDao =  new EquipmentDAOImpl();
		List<Equipment> listequipments = eqpDao.selectAllEquipments();
		return listequipments;
	}

		
		 

}


































//https://uwa.netvibes.com/docs/Uwa/html/index.html
//https://uwa.netvibes.com/docs/Uwa/html/Model.html






