package com.java.layer4;

import java.util.List;


import com.java.layer2.EquipmentProvider;

public interface EquipmentProviderService {
	void saveEquipmentProviderService(EquipmentProvider equipmentProvider) throws EquipmentProviderAlreadyExistsException;
	void modifyEquipmentProviderService(EquipmentProvider equipmentProvider) throws EquipmentProviderNotFoundException;
	//void removeEquipmentService(int equipmentId);
	EquipmentProvider findEquipmentProviderService(int equipmentproviderId) throws EquipmentProviderNotFoundException,EquipmentProviderAlreadyExistsException;
	List<EquipmentProvider> findAllAllEquipmentProvidersService();
}
