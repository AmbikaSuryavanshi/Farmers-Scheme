package com.java.layer4;

public class EquipmentProviderNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EquipmentProviderNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
