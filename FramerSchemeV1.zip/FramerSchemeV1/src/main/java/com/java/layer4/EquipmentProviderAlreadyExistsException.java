package com.java.layer4;

public class EquipmentProviderAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EquipmentProviderAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
