package com.java.layer4;

import java.util.List;

import com.java.layer2.Equipment;

public interface EquipmentService {
	void saveEquipmentService(Equipment equipment) throws EquipmentAlreadyExistsException;
	void modifyEquipmentService(Equipment equipment) throws EquipmentNotFoundException;
	//void removeEquipmentService(int equipmentId);
	Equipment findEquipmentService(int equipmentId) throws EquipmentNotFoundException;
	List<Equipment> findAllAllEquipmentsService();
	
	
	
}

