package com.java.layer2;

public class Bid {
	
	long bidId;
	long bidderId;
	long cropForSaleId;
	float amount;
	
	

	public Bid(long bidId, long bidderId, long cropForSaleId, float amount) {
		super();
		this.bidId = bidId;
		this.bidderId = bidderId;
		this.cropForSaleId = cropForSaleId;
		this.amount = amount;
	}

	public Bid() {
		// TODO Auto-generated constructor stub
	}

	public long getBidId() {
		return bidId;
	}

	public void setBidId(long bidId) {
		this.bidId = bidId;
	}

	public long getBidderId() {
		return bidderId;
	}

	public void setBidderId(long bidderId) {
		this.bidderId = bidderId;
	}

	public long getCropForSaleId() {
		return cropForSaleId;
	}

	public void setCropForSaleId(long cropForSaleId) {
		this.cropForSaleId = cropForSaleId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Bid [bidId=" + bidId + ", bidderId=" + bidderId + ", cropForSaleId=" + cropForSaleId + ", amount="
				+ amount + "]";
	}
	

}
