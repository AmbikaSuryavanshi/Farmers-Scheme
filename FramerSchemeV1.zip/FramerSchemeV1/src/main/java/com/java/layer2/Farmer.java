package com.java.layer2;

import java.util.ArrayList;

public class Farmer {
     long farmerId;
     String farmerName;
     long contact;
     String city;
     String emailId;
     Float farmerRating;
     ArrayList<Crop>crops;
     ArrayList<CropForSale>cropsForSale;
     ArrayList<SuccessfulTransaction>successfulTransactions;
    
	public long getFarmerId() {
		return farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public long getContact() {
		return contact;
	}
	public String getCity() {
		return city;
	}
	public String getEmailId() {
		return emailId;
	}
	public Float getFarmerRating() {
		return farmerRating;
	}
	public ArrayList<Crop> getCrop() {
		return crops;
	}
	public ArrayList<CropForSale> getCropForSale() {
		return cropsForSale;
	}
	public void setFarmerId(long farmerId) {
		this.farmerId = farmerId;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setFarmerRating(Float farmerRating) {
		this.farmerRating = farmerRating;
	}
	public void setCrop(ArrayList<Crop> crop) {
		this.crops = crop;
	}
	public void setCropForSale(ArrayList<CropForSale> cropForSale) {
		this.cropsForSale = cropForSale;
	}
	@Override
	public String toString() {
		return "Farmer [farmerId=" + farmerId + ", farmerName=" + farmerName + ", contact=" + contact + ", city=" + city
				+ ", emailId=" + emailId + ", farmerRating=" + farmerRating + ", crops=" + crops + ", cropsForSale="
				+ cropsForSale + ", successfulTransactions=" + successfulTransactions + "]";
	}

    
    
    
    
}
