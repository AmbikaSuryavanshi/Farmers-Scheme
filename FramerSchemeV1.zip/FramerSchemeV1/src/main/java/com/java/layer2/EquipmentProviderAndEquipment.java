package com.java.layer2;

public class EquipmentProviderAndEquipment {
private int equipmentId;
private long equipmentProviderId;
public EquipmentProviderAndEquipment() {
	System.out.println("EquipmentProviderAndEquipment constructor()...........");
}
public int getEquipmentId() {
	return equipmentId;
}
public void setEquipmentId(int equipmentId) {
	this.equipmentId = equipmentId;
}
public long getEquipmentProviderId() {
	return equipmentProviderId;
}
public void setEquipmentProviderId(long equipmentProviderId) {
	this.equipmentProviderId = equipmentProviderId;
}
@Override
public String toString() {
	return "EquipmentProviderAndEquipment [toString()=" + super.toString() + ", equipmentId=" + equipmentId
			+ ", equipmentProviderId=" + equipmentProviderId + "]";
}


}
