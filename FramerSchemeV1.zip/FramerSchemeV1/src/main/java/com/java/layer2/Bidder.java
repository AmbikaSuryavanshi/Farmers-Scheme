package com.java.layer2;

import java.util.ArrayList;

public class Bidder {
	
	long bidderId;
	String bidderName;
	long contact;
	String city;
	String email;
	float bidderRating;
	ArrayList<Bid> bids;
	ArrayList<SuccessfulTransaction> successfulTransactions; 
	

	public ArrayList<Bid> getBids() {
		return bids;
	}


	public void setBids(ArrayList<Bid> bids) {
		this.bids = bids;
	}


	public ArrayList<SuccessfulTransaction> getSuccessfulTransactions() {
		return successfulTransactions;
	}


	public void setSuccessfulTransactions(ArrayList<SuccessfulTransaction> successfulTransactions) {
		this.successfulTransactions = successfulTransactions;
	}


	public Bidder() {
		// TODO Auto-generated constructor stub
	}


	public long getBidderId() {
		return bidderId;
	}


	public void setBidderId(long bidderId) {
		this.bidderId = bidderId;
	}


	public String getBidderName() {
		return bidderName;
	}


	public void setBidderName(String bidderName) {
		this.bidderName = bidderName;
	}


	public long getContact() {
		return contact;
	}


	public void setContact(long contact) {
		this.contact = contact;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public float getBidderRating() {
		return bidderRating;
	}


	public void setBidderRating(float bidderRating) {
		this.bidderRating = bidderRating;
	}


	public Bidder(long bidderId, String bidderName, long contact, String city, String email, float bidderRating) {
		super();
		this.bidderId = bidderId;
		this.bidderName = bidderName;
		this.contact = contact;
		this.city = city;
		this.email = email;
		this.bidderRating = bidderRating;
	}


	@Override
	public String toString() {
		return "Bidder [bidderId=" + bidderId + ", bidderName=" + bidderName + ", contact=" + contact + ", city=" + city
				+ ", email=" + email + ", bidderRating=" + bidderRating + ", bids=" + bids + ", successfulTransactions="
				+ successfulTransactions + "]";
	}

}
