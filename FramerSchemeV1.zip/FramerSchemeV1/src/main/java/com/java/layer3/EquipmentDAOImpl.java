package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Equipment;

public class EquipmentDAOImpl implements IEquipmentDAO{
	Connection conn;

	public EquipmentDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql:// 10.93.14.52/FarmerSchemeV1", "root", "root123"); // 10.93.14.52***127.0.0.1
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public Equipment selectEquipment(int equipmentId) {
	Equipment equipment= null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipment where equipmentId="+equipmentId); 
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {
				equipment = new Equipment();
				equipment.setEquipmentId(result.getInt(1));
				equipment.setEquipmentName(result.getString(2));
				equipment.setPrice(result.getFloat(3));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return equipment;
	}

	@Override
	public List<Equipment> selectAllEquipments() {
	List<Equipment> equipmentList = new ArrayList<Equipment>();
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipment");
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				Equipment equipment = new Equipment();
				equipment.setEquipmentId(result.getInt(1)); 
				equipment.setEquipmentName(result.getString(2));
				equipment.setPrice(result.getFloat(3));
				equipmentList.add(equipment);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return equipmentList;
	}
	

	@Override
	public void insertEquipment(Equipment equipment) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into equipment(equipmentId,equipmentName,price) values(?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
		 pst.setInt(1, equipment.getEquipmentId());
			
			pst.setString(2, equipment.getEquipmentName());
			pst.setFloat(3, equipment.getPrice());

			int rows = pst.executeUpdate(); 
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void updateEquipment(Equipment equipment) {
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE EQUIPMENT set equipmentName=?, price=? where equipmentId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setString(1, equipment.getEquipmentName());
			pst.setFloat(2, equipment.getPrice());
			pst.setInt(3, equipment.getEquipmentId());
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	/*
	 * @Override public void deleteEquipment(int equipmentId) { try {
	 * PreparedStatement pst =
	 * conn.prepareStatement("DELETE FROM EQUIPMENT  where equipmentId=?");
	 * System.out.println("3. PreparedStatement created....");
	 * 
	 * pst.setInt(1, equipmentId);
	 * 
	 * int rows = pst.executeUpdate();
	 * 
	 * System.out.println("4. executed the delete query: "+rows+ " row(s) updated");
	 * } catch (SQLException e1) { // TODO Auto-generated catch block
	 * e1.printStackTrace(); }
	 * 
	 * }
	 */

}
