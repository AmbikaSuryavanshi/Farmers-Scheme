package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.EquipmentProviderAndEquipment;



public class EquipmentProviderAndEquipmentDAOImpl implements IEquipmentProviderAndEquipmentDAO{
	Connection conn;

	public EquipmentProviderAndEquipmentDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public EquipmentProviderAndEquipment selectEquipmentProviderAndEquipment(int equipmentId, long equipmentProviderId) {
		EquipmentProviderAndEquipment equipmentProviderAndEquipment= null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipmentProviderAndEquipment where equipmentId="+equipmentId+ "AND" +"equipmentProviderId="+equipmentProviderId); 
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {
				equipmentProviderAndEquipment = new EquipmentProviderAndEquipment();
				equipmentProviderAndEquipment.setEquipmentId(result.getInt(1));
				equipmentProviderAndEquipment.setEquipmentProviderId(result.getLong(2));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return equipmentProviderAndEquipment;
		
	}

	
	
	
	@Override
	public List<EquipmentProviderAndEquipment> selectAllEquipmentProviderAndEquipments() {
List<EquipmentProviderAndEquipment> equipmentProviderAndEquipmentList = new ArrayList<EquipmentProviderAndEquipment>();
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipmentProviderAndEquipment");
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				EquipmentProviderAndEquipment equipmentProviderAndEquipment = new EquipmentProviderAndEquipment();
				equipmentProviderAndEquipment.setEquipmentId(result.getInt(1));
				equipmentProviderAndEquipment.setEquipmentProviderId(result.getLong(2)); 
				equipmentProviderAndEquipmentList.add(equipmentProviderAndEquipment);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return equipmentProviderAndEquipmentList;
	}
	
	
	
	
	
	
	@Override
	public void insertEquipmentProviderAndEquipment(EquipmentProviderAndEquipment equipmentProviderAndEquipment) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into equipmentProviderAndEquipment(equipment_Id,equipmentProvider_Id) values(?,?)");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, equipmentProviderAndEquipment.getEquipmentId());
			pst.setLong(1, equipmentProviderAndEquipment.getEquipmentProviderId());

			int rows = pst.executeUpdate(); 
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	
	
	@Override
	public void updateEquipmentProviderAndEquipmentt(EquipmentProviderAndEquipment equipmentProviderAndEquipment) {
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE EQUIPMENTPROVIDERANDEQUIPMENT set equipmentProvider_Id=?,where equipmentId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setLong(1, equipmentProviderAndEquipment.getEquipmentProviderId());
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	
	
	

	@Override
	public void deleteEquipmentProviderAndEquipment(int equipmentId, long equipmentProviderId) {
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM EQUIPMENTPROVIDERANDEQUIPMENT  where equipmentId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, equipmentId);
			
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	

}
