package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Bidder;

public class BidderDAOImpl implements IBidderDAO {
	Connection conn;

	public BidderDAOImpl() {
		// TODO Auto-generated constructor stub
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			System.out.println("Trying to connect to database....");
			conn = DriverManager.getConnection(
	                "jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
			System.out.println("Database connected....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertBidder(Bidder e) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO BidderDetails (bidderId,bidderName,contact,city,emailId,bidderRating) VALUES (?,?,?,?,?,?);");
			
			preparedStatement.setLong(1,e.getBidderId());
			preparedStatement.setString(2,e.getBidderName());
			preparedStatement.setLong(3,e.getContact());
			preparedStatement.setString(4,e.getCity());
			preparedStatement.setString(4,e.getEmail());
			preparedStatement.setFloat(4,e.getBidderRating());
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the insert query : "+rows+ " row(s) inserted");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}

	}

	@Override
	public List<Bidder> selectAllBidders() {
		// TODO Auto-generated method stub
		ArrayList<Bidder> bidders = new ArrayList<Bidder>();
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM BidderDetails;");
			
			while(result.next()) {
				long bidderId =  result.getLong(1);
				String bidderName = result.getString(2);
				long contact = result.getLong(3);
				String city = result.getString(4);
				String emailId = result.getString(5);
				float rating = result.getFloat(6);
				
				Bidder temp = new Bidder(bidderId, bidderName, contact, city, emailId, rating);
				bidders.add(temp);
				
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bidders;
	}

	@Override
	public Bidder selectBidder(long bidderId) {
		// TODO Auto-generated method stub
		Bidder res = null;
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM BidderDetails WHERE bidderId = " + bidderId + ";");
			
			String bidderName="",city="",email="";
			long contact=0;
			float rating=0f;
			
			int flag=0;
			while(result.next()) {
				flag = 1;
				bidderId =  result.getLong(1);
				bidderName =  result.getString(2);
				contact =  result.getLong(3);
				city =  result.getString(4);
				email =  result.getString(5);
				rating =  result.getFloat(6);
				
			}
			
			if(flag==0) {
				System.out.println("No bidder found with given Id");
				res = null;
			}
			else {
				System.out.println("Bidder found with given Id");
				res = new Bidder(bidderId, bidderName, contact, city, email, rating);
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public void updateBidder(Bidder e) {
		// TODO Auto-generated method stub
		long bidderId = e.getBidderId();
		String bidderName = e.getBidderName();
		long contact = e.getContact();
		String city = e.getCity();
		String email = e.getEmail();
		Float rating = e.getBidderRating();
		
		
		
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("UPDATE BidderDetails SET bidderName=?,contact=?,city=?,emailId=?,bidderRating=? WHERE bidderId=?");
			
			
			preparedStatement.setString(1,bidderName);
			preparedStatement.setLong(2,contact);
			preparedStatement.setString(3,city);
			preparedStatement.setString(4,email);
			preparedStatement.setFloat(5,rating);
			preparedStatement.setLong(6,bidderId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the update query : "+rows+ " row(s) updated");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}

	}

	@Override
	public void deleteBidder(long bidderId) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM BidderDetails WHERE bidderId=?");
			preparedStatement.setLong(1,bidderId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the delete query : "+rows+ " row(s) deleted");
			
			preparedStatement.close();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
