package com.java.layer3;

import java.util.List;


import com.java.layer2.InsecticideProvider;

public interface IInsecticideProviderDAO {
	

	InsecticideProvider selectInsecticideProvider(long InsecticideProviderId);
	List<InsecticideProvider> selectAllInsecticideProvider();
	
	void insertInsecticideProvider(InsecticideProvider insecticideprovider);
	void updateInsecticideProvider(InsecticideProvider insecticideprovider);
	void deleteInsecticideProvider(long InsecticideProviderId);

}
