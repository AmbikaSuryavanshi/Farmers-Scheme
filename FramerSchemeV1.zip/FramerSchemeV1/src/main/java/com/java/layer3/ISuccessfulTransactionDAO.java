package com.java.layer3;

import java.util.List;

import com.java.layer2.SuccessfulTransaction;

public interface ISuccessfulTransactionDAO {
	public void insertTransaction(SuccessfulTransaction e);
	public List<SuccessfulTransaction> selectAllTransactions();
	public SuccessfulTransaction selectTransaction(long transactionId);
	public void updateTransaction(SuccessfulTransaction e);
	public void deleteTransaction(long transactionId);
}
