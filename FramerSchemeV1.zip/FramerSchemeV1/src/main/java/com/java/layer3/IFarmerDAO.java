package com.java.layer3;

import java.util.List;

import com.java.layer2.Farmer;

public interface IFarmerDAO {

    Farmer selectFarmer(long farmerId);
	List<Farmer> selectAllFarmers();
	
	void insertFarmer(Farmer farmer);
	void updateFarmer(Farmer farmer);
	void deleteFarmer(long farmerId);
	
}
