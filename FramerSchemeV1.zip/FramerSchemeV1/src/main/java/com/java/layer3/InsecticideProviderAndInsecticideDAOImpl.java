package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.InsecticideProviderAndInsecticide;

public class InsecticideProviderAndInsecticideDAOImpl implements IInsecticideProviderAndInsecticideDAO {
	
	Connection conn;

	public InsecticideProviderAndInsecticideDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public InsecticideProviderAndInsecticide selectInsecticideProviderAndInsecticide(long InsecticideProviderId,int InsecticideId) {
		
		  InsecticideProviderAndInsecticide insecticideproviderandinsecticide = null;
			
			try {
				Statement statement = conn.createStatement();
				System.out.println("3. Statement created....");
				ResultSet result= statement.executeQuery("SELECT*from InsecticideProviderAndInsecticide where InsecticideProviderId="+InsecticideProviderId+"InsecticideId="+InsecticideId);
				System.out.println("4. execute the query");

				System.out.println("5. acquire the result and process it");
				
				if(result.next())
				{
					insecticideproviderandinsecticide= new InsecticideProviderAndInsecticide();
					insecticideproviderandinsecticide.setInsecticideProviderId(result.getLong(1));
					insecticideproviderandinsecticide.setInsecticideId(result.getInt(2));
					
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return insecticideproviderandinsecticide;
			
		
		
	}

	@Override
	public List<InsecticideProviderAndInsecticide> selectAllInsecticideProviderAndInsecticide() {
		 List<InsecticideProviderAndInsecticide> InsecticideProviderAndInsecticideList = new ArrayList<InsecticideProviderAndInsecticide>();
		 
		 try {
			Statement statement = conn.createStatement();
				System.out.println("3. Statement created....");
				ResultSet result = statement.executeQuery("SELECT * FROM InsecticideProviderAndInsecticide"); //eid, ename, job, sal    cid,cname,city,pin
				System.out.println("4. execute the query");

				System.out.println("5. acquire the result and process it");
				
				while(result.next())
				{
					InsecticideProviderAndInsecticide insecticideproviderandinsecticide= new InsecticideProviderAndInsecticide();
					insecticideproviderandinsecticide.setInsecticideProviderId(result.getLong(1));
					insecticideproviderandinsecticide.setInsecticideId(result.getInt(2));
					
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			return InsecticideProviderAndInsecticideList;
		
		
	}

	@Override
	public void insertInsecticideProviderAndInsecticide(
			InsecticideProviderAndInsecticide insecticideproviderandinsecticide) {

		try {
			PreparedStatement pst = conn.prepareStatement("insert into InsecticideProviderAndInsecticide(InsecticideProviderId,InsecticideId) values(?,?)");
			System.out.println("3. PreparedStatement created....");
			pst.setLong(1, insecticideproviderandinsecticide.getInsecticideProviderId());
			pst.setInt(2, insecticideproviderandinsecticide.getInsecticideId());
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateInsecticideProviderAndInsecticide(
			InsecticideProviderAndInsecticide insecticideproviderandinsecticide) {
		try {
			PreparedStatement pst= conn.prepareStatement("update InsecticideProviderAndInsecticide InsecticideProviderId=?,Insecticide=?");
			System.out.println("Prepared statement created");
			pst.setLong(1, insecticideproviderandinsecticide.getInsecticideProviderId());
			pst.setInt(2,insecticideproviderandinsecticide.getInsecticideId());
			int rows= pst.executeUpdate();
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteInsecticideProviderAndInsecticide(long InsecticideProviderId, int InsecticideId) {
	
		try {
			PreparedStatement pst = conn.prepareStatement("delete from InsecticideProvider where InsecticideProviderId=? and InsecticideId=?");
			System.out.println("3. PreparedStatement created....");
			pst.setLong(1, InsecticideProviderId);
			pst.setInt(2, InsecticideId);
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
