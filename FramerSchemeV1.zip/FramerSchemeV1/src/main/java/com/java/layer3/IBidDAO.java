package com.java.layer3;

import java.util.List;

import com.java.layer2.Bid;

public interface IBidDAO {
	public void insertBid(Bid e);
	public List<Bid> selectAllBids();
	public Bid selectBid(long bidId);
	public void updateBid(Bid e);
	public void deleteBid(long bidId);
}
