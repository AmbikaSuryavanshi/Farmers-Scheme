package com.java.layer3;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.java.layer2.SuccessfulTransaction;

public class SuccessfulTransactionDAOImpl implements ISuccessfulTransactionDAO {

	Connection conn;
	
	public SuccessfulTransactionDAOImpl() {
		// TODO Auto-generated constructor stub
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			System.out.println("Trying to connect to database....");
			conn = DriverManager.getConnection(
	                "jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
			System.out.println("Database connected....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertTransaction(SuccessfulTransaction e) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO SuccessfulTransaction (bidId,transactionDate) VALUES (?,?);");
			
			preparedStatement.setLong(1,e.getBidId());
			preparedStatement.setDate(2,e.getTransactionDate());
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the insert query : "+rows+ " row(s) inserted");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}
	}

	@Override
	public List<SuccessfulTransaction> selectAllTransactions() {
		// TODO Auto-generated method stub
		ArrayList<SuccessfulTransaction> transactions = new ArrayList<SuccessfulTransaction>();
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM SuccessfulTransaction;");
			
			while(result.next()) {
				long transactionId =  result.getLong(1);
				long bidId = result.getLong(2);
				Date contact = result.getDate(3);
				
				SuccessfulTransaction temp = new SuccessfulTransaction(transactionId, bidId, contact);
				transactions.add(temp);
				
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transactions;
	}

	@Override
	public SuccessfulTransaction selectTransaction(long transactionId) {
		// TODO Auto-generated method stub
		SuccessfulTransaction res = null;
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM SuccessfulTransaction WHERE transactionId = " + transactionId + ";");
			
			Date transactionDate = new Date(transactionId);
			long bidId=0;
			
			int flag=0;
			while(result.next()) {
				flag = 1;
				transactionId =  result.getLong(2);
				bidId =  result.getLong(2);
				transactionDate =  result.getDate(3);
				
			}
			
			if(flag==0) {
				System.out.println("No bidder found with given Aadhar Number");
				res = null;
			}
			else {
				System.out.println("Bidder found with given Aadhar Number");
				res = new SuccessfulTransaction(transactionId, bidId, transactionDate);
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public void updateTransaction(SuccessfulTransaction e) {
		// TODO Auto-generated method stub
		long transactionId = e.getTransactionId();
		long bidId = e.getBidId();
		Date transactionDate = e.getTransactionDate();
		
		
		
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("UPDATE SuccessfulTransaction SET bidId=?,transactionDate=? WHERE transactionId=?");
			
			
			preparedStatement.setLong(1,bidId);
			preparedStatement.setDate(2,transactionDate);
			preparedStatement.setLong(3,transactionId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the update query : "+rows+ " row(s) updated");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}

	}

	@Override
	public void deleteTransaction(long transactionId) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM SuccessfulTransaction WHERE transactionId=?");
			preparedStatement.setLong(1,transactionId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the delete query : "+rows+ " row(s) deleted");
			
			preparedStatement.close();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
