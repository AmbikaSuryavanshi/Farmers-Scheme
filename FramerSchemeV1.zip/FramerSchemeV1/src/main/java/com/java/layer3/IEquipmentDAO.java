package com.java.layer3;

import java.util.List;

import com.java.layer2.Equipment;

public interface IEquipmentDAO {

	Equipment selectEquipment(int equipmentId);
	List<Equipment> selectAllEquipments();
	
	void insertEquipment(Equipment equipment);
	void updateEquipment(Equipment equipment);
	//void deleteEquipment(int equipmentId);
}
