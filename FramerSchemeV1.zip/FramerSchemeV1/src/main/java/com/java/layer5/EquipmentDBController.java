package com.java.layer5;



import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;



import com.java.layer2.Equipment;

import com.java.layer4.EquipmentAlreadyExistsException;
import com.java.layer4.EquipmentNotFoundException;
import com.java.layer4.EquipmentService;
import com.java.layer4.EquipmentServiceImpl;

@Path("/equipmentdb")
public class EquipmentDBController {
		EquipmentService equipmentService = new EquipmentServiceImpl();
	public EquipmentDBController() 
	{ 
		System.out.println("Equipment Service called...");
	}
	
	@POST 
	@Path("/adding")
	public String addIt(Equipment eqpObj) {
		
		try {
			equipmentService.saveEquipmentService(eqpObj);
			return "equipment added successfully";

		} catch (EquipmentAlreadyExistsException e) {
			return e.getMessage();
		}
	}
	@POST 
	@Path("/modifying")
	public String modifyIt(Equipment eqpObj) {
		
		
			try {
				equipmentService.modifyEquipmentService(eqpObj);
				
			} catch (EquipmentNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "equipment modified successfully";
	

	}
	
	@GET
	@Path("/welcome")
	public String Welcome()
	{
		return "welcome to Equipments";
		
	}
}
