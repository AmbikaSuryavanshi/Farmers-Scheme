package com.java.layer5;





import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.Equipment;
import com.java.layer2.EquipmentProvider;
import com.java.layer4.EquipmentAlreadyExistsException;
import com.java.layer4.EquipmentNotFoundException;
import com.java.layer4.EquipmentProviderNotFoundException;
import com.java.layer4.EquipmentService;
import com.java.layer4.EquipmentServiceImpl;

@Path("/equipmentdb")
public class EquipmentDBController {
		EquipmentService equipmentService = new EquipmentServiceImpl();
	public EquipmentDBController() 
	{ 
		System.out.println("Equipment Service called...");
	}
	

	@GET
	@Path("/displayall")
	@Produces(MediaType.APPLICATION_JSON)
	public Response allEquipments(){
		try {
			List<Equipment> equipmentList = equipmentService.findAllAllEquipmentsService();
			return Response
					.status(Response.Status.OK)
					.entity(equipmentList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/display/{eid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEquipment(@PathParam("eid") int equipmentId) {
		try {
			Equipment equipment= equipmentService.findEquipmentService(equipmentId);
			return Response
					.status(Response.Status.OK)
					.entity(equipment)
					.build();
		}
		catch(EquipmentNotFoundException err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@POST 
	@Path("/adding")
	public String addIt(Equipment eqpObj) {
		
		try {
			equipmentService.saveEquipmentService(eqpObj);
			return "equipment added successfully";

		} catch (EquipmentAlreadyExistsException e) {
			return e.getMessage();
		}
	}
	@PUT 
	@Path("/modifying")
	public String modifyIt(Equipment eqpObj) {
		
		
			try {
				equipmentService.modifyEquipmentService(eqpObj);
				
			} catch (EquipmentNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "equipment modified successfully";
	

	}
	
	@GET
	@Path("/welcome")
	public String Welcome()
	{
		return "welcome to Equipments";
		
	}
}
