package com.java.layer5;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.Equipment;
import com.java.layer2.EquipmentProvider;
import com.java.layer4.EquipmentProviderAlreadyExistsException;
import com.java.layer4.EquipmentProviderNotFoundException;
import com.java.layer4.EquipmentProviderService;
import com.java.layer4.EquipmentProviderServiceImpl;
@Path("/equipmentproviderdb")
public class EquipmentProviderDBController {
	EquipmentProviderService equipmentProviderService = new EquipmentProviderServiceImpl();
	public EquipmentProviderDBController() 
	{ 
		System.out.println("EquipmentProvider Service called...");
	}
	
	
	@GET
	@Path("/displayall")
	@Produces(MediaType.APPLICATION_JSON)
	public Response allEquipmentProvider(){
		try {
			List<EquipmentProvider> equipmentProviderList = equipmentProviderService.findAllAllEquipmentProvidersService();
			return Response
					.status(Response.Status.OK)
					.entity(equipmentProviderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/display/{epid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEquipmentProvider(@PathParam("epid") long equipmentProviderId) {
		try {
			EquipmentProvider equipmentProvider= equipmentProviderService.findEquipmentProviderService(equipmentProviderId);
			return Response
					.status(Response.Status.OK)
					.entity(equipmentProvider)
					.build();
		}
		catch(EquipmentProviderNotFoundException err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	
	@POST 
	@Path("/adding")
	public String addIt(EquipmentProvider eqpprovObj) {
		
		try {
			equipmentProviderService.saveEquipmentProviderService(eqpprovObj);
			return "equipmentProvider added successfully";

		} catch (EquipmentProviderAlreadyExistsException e) {
			return e.getMessage();
		}
	}
	@PUT 
	@Path("/modifying")
	public String modifyIt(EquipmentProvider eqpprovObj) {
		
		
			try {
				equipmentProviderService.modifyEquipmentProviderService(eqpprovObj);
				
			} catch (EquipmentProviderNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "equipmentProvider modified successfully";
	

	}
	
	@GET
	@Path("/welcome")
	public String Welcome()
	{
		return "welcome to EquipmentProviders";
		
	}
}
